/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.util.Date;

/**
 *
 * @author 13161000270
 */
public class Empenho {
    //Dados Principais
    String emitente;
    String numeroEmpenho;
    String processo;
    int tipoMaterial;
    
    //Fornecedor
    boolean tipoFornecedor; //Pessoa fisica ou juridica
    String nome;
    String recebimento;
    String prazo;
    
    //Outros dados
    int tipoLicitacao;
    int numeroLicitacao;
    String obs;

    public Empenho(String emitente, String numeroEmpenho, String processo, int tipoMaterial, boolean tipoFornecedor, String nome, String recebimento, String prazo, int tipoLicitacao, int numeroLicitacao, String obs) {
        this.emitente = emitente;
        this.numeroEmpenho = numeroEmpenho;
        this.processo = processo;
        this.tipoMaterial = tipoMaterial;
        this.tipoFornecedor = tipoFornecedor;
        this.nome = nome;
        this.recebimento = recebimento;
        this.prazo = prazo;
        this.tipoLicitacao = tipoLicitacao;
        this.numeroLicitacao = numeroLicitacao;
        this.obs = obs;
    }

    public String getEmitente() {
        return emitente;
    }

    public void setEmitente(String emitente) {
        this.emitente = emitente;
    }

    public String getNumeroEmpenho() {
        return numeroEmpenho;
    }

    public void setNumeroEmpenho(String numeroEmpenho) {
        this.numeroEmpenho = numeroEmpenho;
    }

    public String getProcesso() {
        return processo;
    }

    public void setProcesso(String processo) {
        this.processo = processo;
    }

    public int getTipoMaterial() {
        return tipoMaterial;
    }

    public void setTipoMaterial(int tipoMaterial) {
        this.tipoMaterial = tipoMaterial;
    }

    public boolean isTipoFornecedor() {
        return tipoFornecedor;
    }

    public void setTipoFornecedor(boolean tipoFornecedor) {
        this.tipoFornecedor = tipoFornecedor;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRecebimento() {
        return recebimento;
    }

    public void setRecebimento(String recebimento) {
        this.recebimento = recebimento;
    }

    public String getPrazo() {
        return prazo;
    }

    public void setPrazo(String prazo) {
        this.prazo = prazo;
    }

    public int getTipoLicitacao() {
        return tipoLicitacao;
    }

    public void setTipoLicitacao(int tipoLicitacao) {
        this.tipoLicitacao = tipoLicitacao;
    }

    public int getNumeroLicitacao() {
        return numeroLicitacao;
    }

    public void setNumeroLicitacao(int numeroLicitacao) {
        this.numeroLicitacao = numeroLicitacao;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }

    
}
