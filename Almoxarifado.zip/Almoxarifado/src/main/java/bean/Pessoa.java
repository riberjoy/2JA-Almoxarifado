
package bean;

import java.util.Date;

public class Pessoa {
    boolean pessoa;
    //Pessoa Fisica
    String nome;
    boolean sexo; // false - feminino && true - masculino
    String cpf;
    String nascimento;
    
    //Pessoa Juridica
    String dono;
    String nomeFicticio;
    String email;
    String website;
    String inscricaoEstadual;
    String cnpj;
    String fone;

    public Pessoa(boolean pessoa, String nome, boolean sexo, String cpf, String nascimento) {
        this.pessoa = pessoa;
        this.nome = nome;
        this.sexo = sexo;
        this.cpf = cpf;
        this.nascimento = nascimento;
    }

    public Pessoa(boolean pessoa, String dono, String nomeFicticio, String email, String website, String inscricaoEstadual, String cnpj, String fone) {
        this.pessoa = pessoa;
        this.dono = dono;
        this.nomeFicticio = nomeFicticio;
        this.email = email;
        this.website = website;
        this.inscricaoEstadual = inscricaoEstadual;
        this.cnpj = cnpj;
        this.fone = fone;
    }
    
    

    public String getFone() {
        return fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }
    
    public boolean isPessoa() {
        return pessoa;
    }

    public void setPessoa(boolean pessoa) {
        this.pessoa = pessoa;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public boolean isSexo() {
        return sexo;
    }

    public void setSexo(boolean sexo) {
        this.sexo = sexo;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNascimento() {
        return nascimento;
    }

    public void setNascimento(String nascimento) {
        this.nascimento = nascimento;
    }

    public String getDono() {
        return dono;
    }

    public void setDono(String dono) {
        this.dono = dono;
    }

    public String getNomeFicticio() {
        return nomeFicticio;
    }

    public void setNomeFicticio(String nomeFicticio) {
        this.nomeFicticio = nomeFicticio;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getInscricaoEstadual() {
        return inscricaoEstadual;
    }

    public void setInscricaoEstadual(String inscricaoEstadual) {
        this.inscricaoEstadual = inscricaoEstadual;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    
    
}
