package gui;

import bean.Empenho;
import bean.Itens;
import bean.Pessoa;
import com.itextpdf.text.BadElementException;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import static java.awt.image.ImageObserver.ALLBITS;
import static java.awt.image.ImageObserver.SOMEBITS;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import javax.swing.tree.DefaultTreeCellEditor;
import relatorios.relatorioEmpenho;
import relatorios.relatorioEntrada;
import relatorios.relatorioEstoque;
import relatorios.relatorioMensal;
import relatorios.relatorioPessoa;
import relatorios.relatorioSaida;

/**
 *
 * @author samue
 */
public class TelaPrincipal extends javax.swing.JFrame {

    Pessoa pessoa = null;
    Empenho empenho = null;
    Itens itens = null;
    Itens itensAux[] = null;
    int i=0;
    
    public TelaPrincipal(){
        initComponents();
        BasicInternalFrameUI bi = (BasicInternalFrameUI)IFOpcoes.getUI();
        bi.setNorthPane(null);
        //this.setResizable(false);
       
        
       // Toolkit t = Toolkit.getDefaultToolkit();
       // Dimension dimensao = t.getScreenSize();
       // this.setSize((dimensao.width), (dimensao.height));    
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnGrupTipoPessoa = new javax.swing.ButtonGroup();
        btnGrupTipoFornecedor = new javax.swing.ButtonGroup();
        btnGroupSexoPessoa = new javax.swing.ButtonGroup();
        btnGroupBuscaPessoa = new javax.swing.ButtonGroup();
        btnGroupBuscaEmpenho = new javax.swing.ButtonGroup();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea4 = new javax.swing.JTextArea();
        PainelSuperiorDados = new javax.swing.JPanel();
        Foto = new javax.swing.JPanel();
        Titulo = new javax.swing.JLabel();
        NomeUsuario = new javax.swing.JLabel();
        OpSair = new javax.swing.JLabel();
        PainelInferiorOpcoes = new javax.swing.JPanel();
        IFOpcoes = new javax.swing.JInternalFrame();
        Principal = new javax.swing.JPanel();
        Inicio = new javax.swing.JPanel();
        BuscaEntradas = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<String>();
        jLabel6 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jComboBox8 = new javax.swing.JComboBox();
        jLabel42 = new javax.swing.JLabel();
        jTextField11 = new javax.swing.JTextField();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        CadEmpenho = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox<String>();
        jLabel10 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<String>();
        jPanel2 = new javax.swing.JPanel();
        lCadEmpNome = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jTextField8 = new javax.swing.JTextField();
        jRadioButton2 = new javax.swing.JRadioButton();
        jRadioButton1 = new javax.swing.JRadioButton();
        jSeparator5 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        ftfDataReceb = new javax.swing.JFormattedTextField();
        lCadEmpNomeEmpresa = new javax.swing.JLabel();
        tfCadEmpNome = new javax.swing.JTextField();
        tflCadEmpNomeEmpresa = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jComboBox4 = new javax.swing.JComboBox<String>();
        jLabel21 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jTextField10 = new javax.swing.JTextField();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTextArea3 = new javax.swing.JTextArea();
        jPanel5 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jComboBox5 = new javax.swing.JComboBox<String>();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jTextField12 = new javax.swing.JTextField();
        jTextField13 = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        cadEmpenho_Obs = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        CadPessoa = new javax.swing.JPanel();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        rbPessoaFisica = new javax.swing.JRadioButton();
        rbPessoaJuridica = new javax.swing.JRadioButton();
        jSeparator7 = new javax.swing.JSeparator();
        tfWebSite = new javax.swing.JTextField();
        lNomeEmpresa = new javax.swing.JLabel();
        ftfTelefone = new javax.swing.JFormattedTextField();
        tfInscricaoEstadual = new javax.swing.JTextField();
        tfNomeEmpresa = new javax.swing.JTextField();
        lEmail = new javax.swing.JLabel();
        lInscricaoEstadual = new javax.swing.JLabel();
        lWebSite = new javax.swing.JLabel();
        lTelefone = new javax.swing.JLabel();
        lCnpj = new javax.swing.JLabel();
        tfNomeDono = new javax.swing.JTextField();
        tfEmail = new javax.swing.JTextField();
        ftfCnpj = new javax.swing.JFormattedTextField();
        lNome = new javax.swing.JLabel();
        LSexo = new javax.swing.JLabel();
        rbFeminino = new javax.swing.JRadioButton();
        rbMasculino = new javax.swing.JRadioButton();
        lCpf = new javax.swing.JLabel();
        tfCpf = new javax.swing.JTextField();
        lDataNasc = new javax.swing.JLabel();
        tfDataNasc = new javax.swing.JTextField();
        ConsultaEmpenho = new javax.swing.JPanel();
        scroll = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();
        buscar = new javax.swing.JButton();
        bPrintAll = new javax.swing.JButton();
        bPrintSelecionado = new javax.swing.JButton();
        jPanel13 = new javax.swing.JPanel();
        opEntrada = new javax.swing.JRadioButton();
        opSaida = new javax.swing.JRadioButton();
        opAll = new javax.swing.JRadioButton();
        jSeparator2 = new javax.swing.JSeparator();
        tPeriodoInicial = new javax.swing.JTextField();
        a = new javax.swing.JLabel();
        tPeriodoFinal = new javax.swing.JTextField();
        labelFornecedor = new javax.swing.JLabel();
        tFornecedor = new javax.swing.JTextField();
        labelNumeroEmpenho = new javax.swing.JLabel();
        tNumeroEmpenho = new javax.swing.JTextField();
        ConsultaEstoque = new javax.swing.JPanel();
        Buscar = new javax.swing.JButton();
        scroll1 = new javax.swing.JScrollPane();
        tabela1 = new javax.swing.JTable();
        bPrintAll1 = new javax.swing.JButton();
        bPrintSelecionado1 = new javax.swing.JButton();
        jPanel14 = new javax.swing.JPanel();
        ListaItens = new javax.swing.JComboBox<String>();
        labelNome = new javax.swing.JLabel();
        tNome = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        labelNome1 = new javax.swing.JLabel();
        tCodigo = new javax.swing.JTextField();
        ConsultaPessoa = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabela2 = new javax.swing.JTable();
        buscar1 = new javax.swing.JButton();
        bPrintAll2 = new javax.swing.JButton();
        bPrintSelecionado2 = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        opPF = new javax.swing.JRadioButton();
        opPJ = new javax.swing.JRadioButton();
        separador1 = new javax.swing.JSeparator();
        lBuscarNome = new javax.swing.JLabel();
        tfBuscaNome = new javax.swing.JTextField();
        lCPF = new javax.swing.JLabel();
        ftfBuscarCpf = new javax.swing.JFormattedTextField();
        lBuscarCnpj = new javax.swing.JLabel();
        ftfBuscarCnpj = new javax.swing.JFormattedTextField();
        labelCPFeCNPJ2 = new javax.swing.JLabel();
        ftfBuscarCnpjECpf = new javax.swing.JFormattedTextField();
        ResumoEntrada = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jButton24 = new javax.swing.JButton();
        jButton25 = new javax.swing.JButton();
        jButton26 = new javax.swing.JButton();
        jButton27 = new javax.swing.JButton();
        MovimentacaoEntrada = new javax.swing.JPanel();
        jLabel41 = new javax.swing.JLabel();
        jButton14 = new javax.swing.JButton();
        jPanel17 = new javax.swing.JPanel();
        jFormattedTextField2 = new javax.swing.JFormattedTextField();
        jTextField21 = new javax.swing.JTextField();
        jLabel37 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jTextField20 = new javax.swing.JTextField();
        jTextField19 = new javax.swing.JTextField();
        jLabel40 = new javax.swing.JLabel();
        jFormattedTextField1 = new javax.swing.JFormattedTextField();
        jLabel39 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jComboBox9 = new javax.swing.JComboBox<String>();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        MovimentacaoSaida = new javax.swing.JPanel();
        jButton20 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jLabel47 = new javax.swing.JLabel();
        jTextField16 = new javax.swing.JTextField();
        jComboBox10 = new javax.swing.JComboBox<String>();
        jLabel69 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jTextField17 = new javax.swing.JTextField();
        jButton15 = new javax.swing.JButton();
        jScrollPane9 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jLabel71 = new javax.swing.JLabel();
        jButton21 = new javax.swing.JButton();
        MovimentaçãoMensal = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jTextField9 = new javax.swing.JTextField();
        jComboBox7 = new javax.swing.JComboBox<String>();
        jButton28 = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jButton29 = new javax.swing.JButton();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jMenuBar2 = new javax.swing.JMenuBar();
        mInicio = new javax.swing.JMenu();
        mCad = new javax.swing.JMenu();
        mCadPessoa = new javax.swing.JMenuItem();
        mCadCadEmpenho = new javax.swing.JMenuItem();
        mConsulta = new javax.swing.JMenu();
        mConsultaPessoa = new javax.swing.JMenuItem();
        mConsultaEmpenho = new javax.swing.JMenuItem();
        mBuscarEntradas = new javax.swing.JMenuItem();
        mConsultaEstoque = new javax.swing.JMenuItem();
        mMov = new javax.swing.JMenu();
        mMovEntrada = new javax.swing.JMenuItem();
        mMovBuscas = new javax.swing.JMenuItem();
        mRelatorioMensal = new javax.swing.JMenuItem();

        jTextArea4.setColumns(20);
        jTextArea4.setRows(5);
        jScrollPane2.setViewportView(jTextArea4);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(1030, 795));

        PainelSuperiorDados.setBackground(new java.awt.Color(102, 102, 102));

        javax.swing.GroupLayout FotoLayout = new javax.swing.GroupLayout(Foto);
        Foto.setLayout(FotoLayout);
        FotoLayout.setHorizontalGroup(
            FotoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        FotoLayout.setVerticalGroup(
            FotoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        Titulo.setBackground(new java.awt.Color(255, 255, 255));
        Titulo.setFont(new java.awt.Font("Book Antiqua", 0, 36)); // NOI18N
        Titulo.setForeground(new java.awt.Color(255, 255, 255));
        Titulo.setText("Almoxarifado");

        NomeUsuario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        NomeUsuario.setForeground(new java.awt.Color(255, 255, 255));
        NomeUsuario.setText("Usuario");

        OpSair.setBackground(new java.awt.Color(255, 204, 0));
        OpSair.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        OpSair.setForeground(new java.awt.Color(255, 255, 51));
        OpSair.setText("Sair");

        javax.swing.GroupLayout PainelSuperiorDadosLayout = new javax.swing.GroupLayout(PainelSuperiorDados);
        PainelSuperiorDados.setLayout(PainelSuperiorDadosLayout);
        PainelSuperiorDadosLayout.setHorizontalGroup(
            PainelSuperiorDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PainelSuperiorDadosLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(Foto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(PainelSuperiorDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PainelSuperiorDadosLayout.createSequentialGroup()
                        .addComponent(Titulo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(OpSair))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PainelSuperiorDadosLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(NomeUsuario)))
                .addContainerGap())
        );
        PainelSuperiorDadosLayout.setVerticalGroup(
            PainelSuperiorDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PainelSuperiorDadosLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Titulo))
            .addGroup(PainelSuperiorDadosLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(PainelSuperiorDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Foto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(PainelSuperiorDadosLayout.createSequentialGroup()
                        .addComponent(NomeUsuario)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(OpSair)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        PainelInferiorOpcoes.setPreferredSize(new java.awt.Dimension(1030, 725));

        IFOpcoes.setAutoscrolls(true);
        IFOpcoes.setPreferredSize(new java.awt.Dimension(1030, 725));
        IFOpcoes.setVisible(true);

        Principal.setLayout(new java.awt.CardLayout());

        Inicio.setPreferredSize(new java.awt.Dimension(1024, 720));

        javax.swing.GroupLayout InicioLayout = new javax.swing.GroupLayout(Inicio);
        Inicio.setLayout(InicioLayout);
        InicioLayout.setHorizontalGroup(
            InicioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        InicioLayout.setVerticalGroup(
            InicioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        Principal.add(Inicio, "Inicio");

        BuscaEntradas.setPreferredSize(new java.awt.Dimension(1024, 720));

        jButton1.setText("Buscar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Buscar entrada"));

        jLabel4.setText("Tipo de material:");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Qualquer", "COMBUSTIVEIS E LUBRIFICANTES AUTOMOTIVOS", "COMBUSTIVEIS E LUBRIFICANTES DE AVIACAO", "COMBUSTIVEIS E LUBRIF. P/ OUTRAS FINALIDADES", "GAS E OUTROS MATERIAIS ENGARRAFADOS", "EXPLOSIVOS E MUNICOES", "ALIMENTOS PARA ANIMAIS", "GENEROS DE ALIMENTACAO", "ANIMAIS PARA PESQUISA E ABATE", "MATERIAL FARMACOLOGICO", "MATERIAL ODONTOLOGICO", "MATERIAL QUIMICO", "MATERIAL DE COUDELARIA OU DE USO ZOOTECNICO", "MATERIAL DE CACA E PESCA", "MATERIAL EDUCATIVO E ESPORTIVO", "MATERIAL P/ FESTIVIDADES E HOMENAGENS", "MATERIAL DE EXPEDIENTE", "MATERIAL DE PROCESSAMENTO DE DADOS", "MATERIAIS E MEDICAMENTOS P/ USO VETERINARIO", "MATERIAL DE ACONDICIONAMENTO E EMBALAGEM", "MATERIAL DE CAMA, MESA E BANHO", "MATERIAL DE COPA E COZINHA", "MATERIAL DE LIMPEZA E PROD. DE HIGIENIZACAO", "UNIFORMES, TECIDOS E AVIAMENTOS", "MATERIAL P/ MANUT.DE BENS IMOVEIS/INSTALACOES", "MATERIAL P/ MANUTENCAO DE BENS MOVEIS", "MATERIAL ELETRICO E ELETRONICO", "MATERIAL DE MANOBRA E PATRULHAMENTO", "MATERIAL DE PROTECAO E SEGURANCA", "MATERIAL P/ AUDIO, VIDEO E FOTO", "MATERIAL PARA COMUNICACOES", "SEMENTES, MUDAS DE PLANTAS E INSUMOS", "SUPRIMENTO DE AVIACAO", "MATERIAL P/ PRODUCAO INDUSTRIAL", "SOBRESSAL. MAQ.E MOTORES NAVIOS E EMBARCACOES", "MATERIAL LABORATORIAL", "MATERIAL HOSPITALAR", "SOBRESSALENTES DE ARMAMENTO", "SUPRIMENTO DE PROTECAO AO VOO", "MATERIAL P/ MANUTENCAO DE VEICULOS", "MATERIAL BIOLOGICO", "MATERIAL P/ UTILIZACAO EM GRAFICA", "FERRAMENTAS", "MATERIAL P/ REABILITACAO PROFISSIONAL", "MATERIAL DE SINALIZACAO VISUAL E OUTROS", "MATERIAL TECNICO P/ SELECAO E TREINAMENTO", "MATERIAL BIBLIOGRAFICO", "AQUISICAO DE SOFTWARES DE BASE", "BENS MOVEIS NAO ATIVAVEIS", "BILHETES DE PASSAGEM", "BANDEIRAS, FLAMULAS E INSIGNIAS", "DISCOTECAS E FILMOTECAS NAO IMOBILIZAVEL", "MATERIAL DE CARATER SECRETO OU RESERVADO", "MATERIAL METEOROLOGICO", "MATERIAL P/MANUT.CONSERV.DE ESTRADAS E VIAS", "SELOS PARA CONTROLE FISCAL", "MATERIAL DE CONSUMO - PAGTO ANTECIPADO" }));

        jLabel6.setText("Fornecedor:");

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jLabel5.setText("Período de");

        jLabel7.setText("à");

        jLabel34.setText("Tipo material:");

        jComboBox8.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel42.setText("Processo:");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jTextField1)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 8, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jComboBox1, 0, 368, Short.MAX_VALUE))
                .addGap(26, 26, 26)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel34)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox8, javax.swing.GroupLayout.PREFERRED_SIZE, 357, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel42)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jLabel4, jLabel5, jLabel6});

        jPanel4Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jLabel34, jLabel42});

        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel34)
                    .addComponent(jComboBox8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel42)
                        .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel6)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(7, 7, 7)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 12, Short.MAX_VALUE))
        );

        jLabel43.setText("Resultados");

        jLabel44.setText("------------");

        javax.swing.GroupLayout BuscaEntradasLayout = new javax.swing.GroupLayout(BuscaEntradas);
        BuscaEntradas.setLayout(BuscaEntradasLayout);
        BuscaEntradasLayout.setHorizontalGroup(
            BuscaEntradasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BuscaEntradasLayout.createSequentialGroup()
                .addGroup(BuscaEntradasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(BuscaEntradasLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(BuscaEntradasLayout.createSequentialGroup()
                        .addGroup(BuscaEntradasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(BuscaEntradasLayout.createSequentialGroup()
                                .addGap(380, 380, 380)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(BuscaEntradasLayout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addComponent(jLabel43))
                            .addGroup(BuscaEntradasLayout.createSequentialGroup()
                                .addGap(48, 48, 48)
                                .addComponent(jLabel44)))
                        .addGap(0, 409, Short.MAX_VALUE)))
                .addContainerGap())
        );
        BuscaEntradasLayout.setVerticalGroup(
            BuscaEntradasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BuscaEntradasLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addGap(18, 18, 18)
                .addComponent(jLabel43)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel44)
                .addContainerGap())
        );

        Principal.add(BuscaEntradas, "BuscaEntradas");

        CadEmpenho.setPreferredSize(new java.awt.Dimension(1024, 720));
        CadEmpenho.setRequestFocusEnabled(false);
        CadEmpenho.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton2.setText("Cadastrar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        CadEmpenho.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 610, -1, -1));

        jButton3.setText("Cancelar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        CadEmpenho.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 610, -1, -1));

        jButton4.setText("Limpar campos");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        CadEmpenho.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 610, -1, -1));

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados Principais"));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setText("UG Emitente:");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 112, 20));

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox3.setToolTipText("Unidade Gestora Emitente");
        jComboBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox3ActionPerformed(evt);
            }
        });
        jPanel1.add(jComboBox3, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 20, 300, -1));

        jLabel10.setText("Número de Empenho: *");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, -1, 30));

        jTextField5.setToolTipText("Processo desta instituição relativo a este empenho");
        jTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 80, 300, -1));

        jTextField4.setToolTipText("Formato: \"9999NE123456\"");
        jPanel1.add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 50, 300, -1));

        jLabel11.setText("Processo: *");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 112, 20));

        jLabel12.setText("Tipo de Material:");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 112, 20));

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });
        jPanel1.add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 110, 300, -1));

        CadEmpenho.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 34, 470, 150));

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados do Fornecedor"));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lCadEmpNome.setText("Nome:");
        jPanel2.add(lCadEmpNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 107, 20));

        jLabel16.setText("Data de Recebimento:");
        jPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, 20));

        jLabel17.setText("Prazo:");
        jPanel2.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 107, 20));

        jTextField8.setToolTipText("Prazo em dias, contados a partir da data de recebimento, que o fornecedor tem para concluir a entrega dos itens empenhados");
        jTextField8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField8ActionPerformed(evt);
            }
        });
        jPanel2.add(jTextField8, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 110, 154, -1));

        btnGrupTipoFornecedor.add(jRadioButton2);
        jRadioButton2.setText("Pessoa Física");
        jRadioButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jRadioButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 20, -1, -1));

        btnGrupTipoFornecedor.add(jRadioButton1);
        jRadioButton1.setText("Pessoa Jurídica");
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jRadioButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 20, -1, -1));
        jPanel2.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 42, 500, 0));
        jPanel2.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 500, 10));

        try {
            ftfDataReceb.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel2.add(ftfDataReceb, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 80, 100, -1));

        lCadEmpNomeEmpresa.setText("Nome da empresa:");
        jPanel2.add(lCadEmpNomeEmpresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, 20));
        jPanel2.add(tfCadEmpNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 50, 350, -1));
        jPanel2.add(tflCadEmpNomeEmpresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 50, 350, -1));

        CadEmpenho.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(494, 34, 520, 150));

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Outros Dados"));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel19.setText("Tipos de Licitação:");
        jPanel3.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(14, 30, -1, 20));

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox4ActionPerformed(evt);
            }
        });
        jPanel3.add(jComboBox4, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 30, 200, -1));

        jLabel21.setText("Observação:");
        jPanel3.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, 72, -1));

        jLabel20.setText("N° da Licitação:");
        jPanel3.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 30, -1, 20));
        jPanel3.add(jTextField10, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 30, 172, -1));

        jTextArea3.setColumns(20);
        jTextArea3.setRows(5);
        jTextArea3.setAutoscrolls(false);
        jScrollPane7.setViewportView(jTextArea3);

        jPanel3.add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 60, 860, -1));

        CadEmpenho.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 190, 1004, 170));

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder("Empenhar Novo Item"));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel23.setText("Categoria: *");
        jPanel5.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 128, 20));

        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox5ActionPerformed(evt);
            }
        });
        jPanel5.add(jComboBox5, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 30, 310, -1));

        jLabel24.setText("Observação:");
        jPanel5.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, 128, -1));

        jLabel25.setText("Quantidade Empenhada: *");
        jPanel5.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, 30));

        jTextField12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField12ActionPerformed(evt);
            }
        });
        jPanel5.add(jTextField12, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 170, 108, -1));

        jTextField13.setToolTipText("Formato: \"9.999,99\"");
        jTextField13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField13ActionPerformed(evt);
            }
        });
        jPanel5.add(jTextField13, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 200, 180, -1));

        jLabel26.setText("Valor Total: *");
        jPanel5.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, 128, 20));

        jButton5.setText("Adicionar Item ao Empenho");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 200, -1, -1));

        cadEmpenho_Obs.setColumns(20);
        cadEmpenho_Obs.setRows(5);
        jScrollPane6.setViewportView(cadEmpenho_Obs);

        jPanel5.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 60, 860, -1));

        CadEmpenho.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 360, 1000, 240));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Cadastro de Empenho");
        CadEmpenho.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 11, -1, -1));
        CadEmpenho.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        Principal.add(CadEmpenho, "CadEmpenho");

        CadPessoa.setPreferredSize(new java.awt.Dimension(1024, 720));

        jButton10.setText("Cadastrar");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton11.setText("Cancelar");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jButton12.setText("Zerar Campos");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jButton13.setText("Cadastrar e adicionar outro(a)");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Cadastrar Pessoa"));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnGrupTipoPessoa.add(rbPessoaFisica);
        rbPessoaFisica.setText("Pessoa Física");
        rbPessoaFisica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbPessoaFisicaActionPerformed(evt);
            }
        });
        jPanel6.add(rbPessoaFisica, new org.netbeans.lib.awtextra.AbsoluteConstraints(382, 16, -1, -1));

        btnGrupTipoPessoa.add(rbPessoaJuridica);
        rbPessoaJuridica.setText("Pessoa Jurídica");
        rbPessoaJuridica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbPessoaJuridicaActionPerformed(evt);
            }
        });
        jPanel6.add(rbPessoaJuridica, new org.netbeans.lib.awtextra.AbsoluteConstraints(489, 16, -1, -1));
        jPanel6.add(jSeparator7, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 41, 990, 10));
        jPanel6.add(tfWebSite, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 140, 550, -1));

        lNomeEmpresa.setText("Nome da empresa:");
        jPanel6.add(lNomeEmpresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, -1, -1));

        try {
            ftfTelefone.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("(##)####-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel6.add(ftfTelefone, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 110, 131, -1));
        jPanel6.add(tfInscricaoEstadual, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 140, 200, -1));
        jPanel6.add(tfNomeEmpresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 80, 540, -1));

        lEmail.setText("E-mail:");
        jPanel6.add(lEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, -1, -1));

        lInscricaoEstadual.setText("Inscrição estadual:");
        jPanel6.add(lInscricaoEstadual, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 140, -1, 20));

        lWebSite.setText("Web site:");
        jPanel6.add(lWebSite, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, -1, -1));

        lTelefone.setText("Telefone:");
        jPanel6.add(lTelefone, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 110, -1, 20));

        lCnpj.setText("CNPJ:");
        jPanel6.add(lCnpj, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 80, -1, 20));
        jPanel6.add(tfNomeDono, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 50, 600, -1));
        jPanel6.add(tfEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 110, 550, -1));

        try {
            ftfCnpj.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##.###.###/####-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        ftfCnpj.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ftfCnpjActionPerformed(evt);
            }
        });
        jPanel6.add(ftfCnpj, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 80, 116, -1));

        lNome.setText("Nome: *");
        jPanel6.add(lNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, -1, -1));

        LSexo.setText("Sexo: *");
        jPanel6.add(LSexo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 40, 20));

        btnGroupSexoPessoa.add(rbFeminino);
        rbFeminino.setText("Feminino");
        rbFeminino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbFemininoActionPerformed(evt);
            }
        });
        jPanel6.add(rbFeminino, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 80, -1, -1));

        btnGroupSexoPessoa.add(rbMasculino);
        rbMasculino.setText("Masculino");
        jPanel6.add(rbMasculino, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 80, -1, -1));

        lCpf.setText("CPF: *");
        jPanel6.add(lCpf, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 40, 20));
        jPanel6.add(tfCpf, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, 191, -1));

        lDataNasc.setText("Data de Nascimento:");
        jPanel6.add(lDataNasc, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, -1, 20));
        jPanel6.add(tfDataNasc, new org.netbeans.lib.awtextra.AbsoluteConstraints(125, 140, 170, -1));

        javax.swing.GroupLayout CadPessoaLayout = new javax.swing.GroupLayout(CadPessoa);
        CadPessoa.setLayout(CadPessoaLayout);
        CadPessoaLayout.setHorizontalGroup(
            CadPessoaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CadPessoaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(CadPessoaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(CadPessoaLayout.createSequentialGroup()
                        .addComponent(jButton12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton11)))
                .addContainerGap())
        );

        CadPessoaLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jButton10, jButton11, jButton12});

        CadPessoaLayout.setVerticalGroup(
            CadPessoaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CadPessoaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(CadPessoaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton10)
                    .addComponent(jButton11)
                    .addComponent(jButton12)
                    .addComponent(jButton13))
                .addContainerGap(439, Short.MAX_VALUE))
        );

        Principal.add(CadPessoa, "CadPessoa");

        ConsultaEmpenho.setPreferredSize(new java.awt.Dimension(1024, 720));

        tabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Número", "Entrada/Saída", "Data Cadastro", "Itens", "Valor", "Processo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        scroll.setViewportView(tabela);

        buscar.setText("Buscar");
        buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarActionPerformed(evt);
            }
        });

        bPrintAll.setText("PDF (Todos do Resultado)");
        bPrintAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPrintAllActionPerformed(evt);
            }
        });

        bPrintSelecionado.setText("Exibir PDF (Selecionado)");
        bPrintSelecionado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPrintSelecionadoActionPerformed(evt);
            }
        });

        jPanel13.setBorder(javax.swing.BorderFactory.createTitledBorder("Buscar por"));

        btnGroupBuscaEmpenho.add(opEntrada);
        opEntrada.setText("Entradas");
        opEntrada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opEntradaActionPerformed(evt);
            }
        });

        btnGroupBuscaEmpenho.add(opSaida);
        opSaida.setText("Saídas");
        opSaida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opSaidaActionPerformed(evt);
            }
        });

        btnGroupBuscaEmpenho.add(opAll);
        opAll.setText("Todas (Entradas/Saídas)");
        opAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opAllActionPerformed(evt);
            }
        });

        tPeriodoInicial.setText("  - - / - - / - -");
        tPeriodoInicial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tPeriodoInicialActionPerformed(evt);
            }
        });

        a.setText("à");

        tPeriodoFinal.setText("  - - / - - / - -");
        tPeriodoFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tPeriodoFinalActionPerformed(evt);
            }
        });

        labelFornecedor.setText("Fornecedor:");

        labelNumeroEmpenho.setText("Número Empenho: ");

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator2)
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addGap(391, 391, 391)
                                .addComponent(tPeriodoInicial, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(a)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tPeriodoFinal, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addGap(279, 279, 279)
                                .addComponent(opEntrada)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(opSaida)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(opAll))
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addGap(202, 202, 202)
                                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(tFornecedor, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                                        .addComponent(labelFornecedor)
                                        .addGap(173, 173, 173)))
                                .addGap(18, 18, 18)
                                .addComponent(labelNumeroEmpenho)
                                .addGap(10, 10, 10)
                                .addComponent(tNumeroEmpenho, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jPanel13Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {opAll, opEntrada, opSaida});

        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(opEntrada)
                    .addComponent(opSaida)
                    .addComponent(opAll))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tPeriodoInicial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(a)
                    .addComponent(tPeriodoFinal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelFornecedor)
                    .addComponent(labelNumeroEmpenho)
                    .addComponent(tNumeroEmpenho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 5, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout ConsultaEmpenhoLayout = new javax.swing.GroupLayout(ConsultaEmpenho);
        ConsultaEmpenho.setLayout(ConsultaEmpenhoLayout);
        ConsultaEmpenhoLayout.setHorizontalGroup(
            ConsultaEmpenhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ConsultaEmpenhoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(ConsultaEmpenhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(scroll)
                    .addGroup(ConsultaEmpenhoLayout.createSequentialGroup()
                        .addGap(376, 376, 376)
                        .addComponent(buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ConsultaEmpenhoLayout.createSequentialGroup()
                .addContainerGap(288, Short.MAX_VALUE)
                .addComponent(bPrintSelecionado)
                .addGap(18, 18, 18)
                .addComponent(bPrintAll, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(278, 278, 278))
        );

        ConsultaEmpenhoLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {bPrintAll, bPrintSelecionado, buscar});

        ConsultaEmpenhoLayout.setVerticalGroup(
            ConsultaEmpenhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ConsultaEmpenhoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(buscar)
                .addGap(18, 18, 18)
                .addComponent(scroll, javax.swing.GroupLayout.DEFAULT_SIZE, 471, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(ConsultaEmpenhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bPrintAll)
                    .addComponent(bPrintSelecionado))
                .addGap(23, 23, 23))
        );

        Principal.add(ConsultaEmpenho, "ConsultaEmpenho");

        ConsultaEstoque.setPreferredSize(new java.awt.Dimension(1024, 720));

        Buscar.setText("Buscar");
        Buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarActionPerformed(evt);
            }
        });

        tabela1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nome", "Descrição", "Quantidade", "Última Compra"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        scroll1.setViewportView(tabela1);

        bPrintAll1.setText("PDF (Todos do Resultado)");
        bPrintAll1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPrintAll1ActionPerformed(evt);
            }
        });

        bPrintSelecionado1.setText("Exibir PDF (Selecionado)");
        bPrintSelecionado1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPrintSelecionado1ActionPerformed(evt);
            }
        });

        jPanel14.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder("Buscar item")));

        ListaItens.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        labelNome.setText("Nome:");

        tNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tNomeActionPerformed(evt);
            }
        });

        jLabel2.setText("Categoria:");

        labelNome1.setText("Código:");

        tCodigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tCodigoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addComponent(labelNome)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tNome))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ListaItens, javax.swing.GroupLayout.PREFERRED_SIZE, 443, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(labelNome1)
                .addGap(10, 10, 10)
                .addComponent(tCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel14Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jLabel2, labelNome});

        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ListaItens, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelNome)
                    .addComponent(tNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelNome1))
                .addGap(0, 8, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout ConsultaEstoqueLayout = new javax.swing.GroupLayout(ConsultaEstoque);
        ConsultaEstoque.setLayout(ConsultaEstoqueLayout);
        ConsultaEstoqueLayout.setHorizontalGroup(
            ConsultaEstoqueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ConsultaEstoqueLayout.createSequentialGroup()
                .addGroup(ConsultaEstoqueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ConsultaEstoqueLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(ConsultaEstoqueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(scroll1)
                            .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(ConsultaEstoqueLayout.createSequentialGroup()
                        .addGap(401, 401, 401)
                        .addComponent(Buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(ConsultaEstoqueLayout.createSequentialGroup()
                .addGap(309, 309, 309)
                .addComponent(bPrintSelecionado1)
                .addGap(18, 18, 18)
                .addComponent(bPrintAll1, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(317, Short.MAX_VALUE))
        );

        ConsultaEstoqueLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {Buscar, bPrintAll1, bPrintSelecionado1});

        ConsultaEstoqueLayout.setVerticalGroup(
            ConsultaEstoqueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ConsultaEstoqueLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Buscar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(scroll1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addGroup(ConsultaEstoqueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bPrintSelecionado1)
                    .addComponent(bPrintAll1))
                .addGap(86, 86, 86))
        );

        Principal.add(ConsultaEstoque, "ConsultaEstoque");

        ConsultaPessoa.setPreferredSize(new java.awt.Dimension(1024, 720));

        tabela2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nome", "Cadastro", "Data Cadastro", "Valor Total de Compras"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tabela2);

        buscar1.setText("Buscar");
        buscar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscar1ActionPerformed(evt);
            }
        });

        bPrintAll2.setText("PDF (Todos do Resultado)");
        bPrintAll2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPrintAll2ActionPerformed(evt);
            }
        });

        bPrintSelecionado2.setText("Exibir PDF (Selecionado)");
        bPrintSelecionado2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPrintSelecionado2ActionPerformed(evt);
            }
        });

        jPanel12.setBorder(javax.swing.BorderFactory.createTitledBorder("Buscar por"));
        jPanel12.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnGroupBuscaPessoa.add(opPF);
        opPF.setText("Pessoas Físicas");
        opPF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opPFActionPerformed(evt);
            }
        });
        jPanel12.add(opPF, new org.netbeans.lib.awtextra.AbsoluteConstraints(256, 16, 141, -1));

        btnGroupBuscaPessoa.add(opPJ);
        opPJ.setText("Pessoas Jurídicas");
        opPJ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opPJActionPerformed(evt);
            }
        });
        jPanel12.add(opPJ, new org.netbeans.lib.awtextra.AbsoluteConstraints(415, 16, 141, -1));
        jPanel12.add(separador1, new org.netbeans.lib.awtextra.AbsoluteConstraints(16, 41, 972, 10));

        lBuscarNome.setText("Nome:");
        jPanel12.add(lBuscarNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 40, -1));
        jPanel12.add(tfBuscaNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(51, 57, 484, -1));

        lCPF.setText("CPF:");
        jPanel12.add(lCPF, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 90, 40, 20));

        try {
            ftfBuscarCpf.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###.###.###-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel12.add(ftfBuscarCpf, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, 134, -1));

        lBuscarCnpj.setText("CNPJ:");
        jPanel12.add(lBuscarCnpj, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 90, 40, 20));

        try {
            ftfBuscarCnpj.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##.###.###/####-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel12.add(ftfBuscarCnpj, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, 134, -1));

        labelCPFeCNPJ2.setText("CNPJ:");
        jPanel12.add(labelCPFeCNPJ2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, -1, 20));

        try {
            ftfBuscarCnpjECpf.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##.###.###/####-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel12.add(ftfBuscarCnpjECpf, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, 134, -1));

        javax.swing.GroupLayout ConsultaPessoaLayout = new javax.swing.GroupLayout(ConsultaPessoa);
        ConsultaPessoa.setLayout(ConsultaPessoaLayout);
        ConsultaPessoaLayout.setHorizontalGroup(
            ConsultaPessoaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ConsultaPessoaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(ConsultaPessoaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1)
                    .addComponent(jPanel12, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 1004, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(ConsultaPessoaLayout.createSequentialGroup()
                .addGap(408, 408, 408)
                .addComponent(buscar1, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ConsultaPessoaLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(bPrintSelecionado2)
                .addGap(18, 18, 18)
                .addComponent(bPrintAll2, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(319, 319, 319))
        );

        ConsultaPessoaLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {bPrintAll2, bPrintSelecionado2, buscar1});

        ConsultaPessoaLayout.setVerticalGroup(
            ConsultaPessoaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ConsultaPessoaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(buscar1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addGroup(ConsultaPessoaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bPrintSelecionado2)
                    .addComponent(bPrintAll2))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Principal.add(ConsultaPessoa, "ConsultaPessoa");

        ResumoEntrada.setPreferredSize(new java.awt.Dimension(1024, 720));

        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados da entrada"));

        jLabel54.setText("Data de entrada:");

        jLabel55.setText("Nº nota fiscal:");

        jLabel56.setText("Data da nota fiscal:");

        jLabel57.setText("Fornecedor:");

        jLabel58.setText("Contato:");

        jLabel59.setText("Empenho:");

        jLabel60.setText("Processo do empenho:");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel59)
                        .addComponent(jLabel60)
                        .addComponent(jLabel56)
                        .addComponent(jLabel55)
                        .addComponent(jLabel54))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel58)
                            .addComponent(jLabel57))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel60)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel59)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel56)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel55)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel54)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel57)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel58)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder("Resumo por elemento de despesa"));

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Conta Contábil", "Descrição", "Valor"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(jTable3);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4)
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(150, Short.MAX_VALUE))
        );

        jButton24.setText("Remover");
        jButton24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton24ActionPerformed(evt);
            }
        });

        jButton25.setText("Gerar PDF Inventario");

        jButton26.setText("Gerar PDF Entrada");
        jButton26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton26ActionPerformed(evt);
            }
        });

        jButton27.setText("Editar");
        jButton27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton27ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ResumoEntradaLayout = new javax.swing.GroupLayout(ResumoEntrada);
        ResumoEntrada.setLayout(ResumoEntradaLayout);
        ResumoEntradaLayout.setHorizontalGroup(
            ResumoEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ResumoEntradaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(ResumoEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ResumoEntradaLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton27)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton26)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton25)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton24)))
                .addContainerGap())
        );
        ResumoEntradaLayout.setVerticalGroup(
            ResumoEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ResumoEntradaLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(ResumoEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton24)
                    .addComponent(jButton25)
                    .addComponent(jButton26)
                    .addComponent(jButton27))
                .addGap(18, 18, 18)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Principal.add(ResumoEntrada, "ResumoEntrada");

        MovimentacaoEntrada.setPreferredSize(new java.awt.Dimension(1024, 720));

        jLabel41.setText("Valor total: R$");

        jButton14.setText("Concluir");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        jPanel17.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados da entrada"));

        try {
            jFormattedTextField2.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jFormattedTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jFormattedTextField2ActionPerformed(evt);
            }
        });

        jTextField21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField21ActionPerformed(evt);
            }
        });

        jLabel37.setText("Nº Nota fiscal:");

        jLabel36.setText("Data nota fiscal:");

        jLabel38.setText("Fornecedor:");

        jTextField20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField20ActionPerformed(evt);
            }
        });

        jTextField19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField19ActionPerformed(evt);
            }
        });

        jLabel40.setText("Empenho:");

        try {
            jFormattedTextField1.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jFormattedTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jFormattedTextField1ActionPerformed(evt);
            }
        });

        jLabel39.setText("Data da entrada:");

        jLabel15.setText("Tipo da entrada:");

        jComboBox9.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox9ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel38)
                                .addComponent(jLabel37)
                                .addComponent(jLabel36))
                            .addComponent(jLabel39)
                            .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jFormattedTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jTextField19)
                                .addComponent(jTextField20)
                                .addComponent(jTextField21, javax.swing.GroupLayout.PREFERRED_SIZE, 438, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jFormattedTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox9, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(447, Short.MAX_VALUE))
        );

        jPanel17Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jLabel36, jLabel37, jLabel38, jLabel39, jLabel40});

        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel39)
                    .addComponent(jFormattedTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(jComboBox9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel40)
                    .addComponent(jTextField19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel38)
                    .addComponent(jTextField20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel37)
                    .addComponent(jTextField21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel36)
                    .addComponent(jFormattedTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 8, Short.MAX_VALUE))
        );

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Marcar?", "Cod.", "ED", "Descrição", "Qnt", "R$ Unitario", "Qnt Recebida", "Vida util em ultimos meses", "Valor da entrada"
            }
        ));
        jScrollPane3.setViewportView(jTable1);

        jLabel45.setText("Selecione os item da entrada");

        jLabel46.setText("0,00");

        javax.swing.GroupLayout MovimentacaoEntradaLayout = new javax.swing.GroupLayout(MovimentacaoEntrada);
        MovimentacaoEntrada.setLayout(MovimentacaoEntradaLayout);
        MovimentacaoEntradaLayout.setHorizontalGroup(
            MovimentacaoEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MovimentacaoEntradaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(MovimentacaoEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(MovimentacaoEntradaLayout.createSequentialGroup()
                        .addComponent(jLabel45)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MovimentacaoEntradaLayout.createSequentialGroup()
                        .addGroup(MovimentacaoEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(MovimentacaoEntradaLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel41)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel46))
                            .addComponent(jPanel17, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jScrollPane3))
                        .addGap(20, 20, 20))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MovimentacaoEntradaLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(409, 409, 409))
        );
        MovimentacaoEntradaLayout.setVerticalGroup(
            MovimentacaoEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MovimentacaoEntradaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel45)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 308, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(MovimentacaoEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel41)
                    .addComponent(jLabel46))
                .addGap(37, 37, 37)
                .addComponent(jButton14)
                .addGap(63, 63, 63))
        );

        Principal.add(MovimentacaoEntrada, "MovimentacaoEntrada");

        MovimentacaoSaida.setPreferredSize(new java.awt.Dimension(1024, 720));

        jButton20.setText("Finalizar");
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });

        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder("Item"));

        jLabel47.setText("Nome: *");

        jTextField16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField16ActionPerformed(evt);
            }
        });

        jComboBox10.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox10ActionPerformed(evt);
            }
        });

        jLabel69.setText("Categoria: *");

        jLabel70.setText("Quantidade: *");

        jTextField17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField17ActionPerformed(evt);
            }
        });

        jButton15.setText("Adicionar itens");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel69)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox10, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel47)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, 435, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 454, Short.MAX_VALUE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel70)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField17, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton15)))
                .addContainerGap())
        );

        jPanel7Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jLabel47, jLabel69, jLabel70});

        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel69)
                    .addComponent(jComboBox10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel47))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel70)
                    .addComponent(jButton15))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Categoria", "Nome", "Descriçao", "Qnt. Inicial", "Qnt. Final"
            }
        ));
        jScrollPane9.setViewportView(jTable4);

        jLabel71.setText("Itens removidos");

        jButton21.setText("Finalizar e gerar PDF");
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout MovimentacaoSaidaLayout = new javax.swing.GroupLayout(MovimentacaoSaida);
        MovimentacaoSaida.setLayout(MovimentacaoSaidaLayout);
        MovimentacaoSaidaLayout.setHorizontalGroup(
            MovimentacaoSaidaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MovimentacaoSaidaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(MovimentacaoSaidaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane9)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(MovimentacaoSaidaLayout.createSequentialGroup()
                        .addComponent(jLabel71)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(MovimentacaoSaidaLayout.createSequentialGroup()
                .addGap(327, 327, 327)
                .addComponent(jButton20, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton21, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        MovimentacaoSaidaLayout.setVerticalGroup(
            MovimentacaoSaidaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MovimentacaoSaidaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel71)
                .addGap(11, 11, 11)
                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addGroup(MovimentacaoSaidaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton20)
                    .addComponent(jButton21))
                .addContainerGap(189, Short.MAX_VALUE))
        );

        Principal.add(MovimentacaoSaida, "MovimentacaoSaida");

        MovimentaçãoMensal.setPreferredSize(new java.awt.Dimension(1024, 720));

        jPanel15.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados referentes ao Balancete"));

        jLabel3.setText("Elemento de despesa:");

        jLabel13.setText("Período de");

        jLabel14.setText("à");

        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Qualquer", "COMBUSTIVEIS E LUBRIFICANTES AUTOMOTIVOS", "COMBUSTIVEIS E LUBRIFICANTES DE AVIACAO", "COMBUSTIVEIS E LUBRIF. P/ OUTRAS FINALIDADES", "GAS E OUTROS MATERIAIS ENGARRAFADOS", "EXPLOSIVOS E MUNICOES", "ALIMENTOS PARA ANIMAIS", "GENEROS DE ALIMENTACAO", "ANIMAIS PARA PESQUISA E ABATE", "MATERIAL FARMACOLOGICO", "MATERIAL ODONTOLOGICO", "MATERIAL QUIMICO", "MATERIAL DE COUDELARIA OU DE USO ZOOTECNICO", "MATERIAL DE CACA E PESCA", "MATERIAL EDUCATIVO E ESPORTIVO", "MATERIAL P/ FESTIVIDADES E HOMENAGENS", "MATERIAL DE EXPEDIENTE", "MATERIAL DE PROCESSAMENTO DE DADOS", "MATERIAIS E MEDICAMENTOS P/ USO VETERINARIO", "MATERIAL DE ACONDICIONAMENTO E EMBALAGEM", "MATERIAL DE CAMA, MESA E BANHO", "MATERIAL DE COPA E COZINHA", "MATERIAL DE LIMPEZA E PROD. DE HIGIENIZACAO", "UNIFORMES, TECIDOS E AVIAMENTOS", "MATERIAL P/ MANUT.DE BENS IMOVEIS/INSTALACOES", "MATERIAL P/ MANUTENCAO DE BENS MOVEIS", "MATERIAL ELETRICO E ELETRONICO", "MATERIAL DE MANOBRA E PATRULHAMENTO", "MATERIAL DE PROTECAO E SEGURANCA", "MATERIAL P/ AUDIO, VIDEO E FOTO", "MATERIAL PARA COMUNICACOES", "SEMENTES, MUDAS DE PLANTAS E INSUMOS", "SUPRIMENTO DE AVIACAO", "MATERIAL P/ PRODUCAO INDUSTRIAL", "SOBRESSAL. MAQ.E MOTORES NAVIOS E EMBARCACOES", "MATERIAL LABORATORIAL", "MATERIAL HOSPITALAR", "SOBRESSALENTES DE ARMAMENTO", "SUPRIMENTO DE PROTECAO AO VOO", "MATERIAL P/ MANUTENCAO DE VEICULOS", "MATERIAL BIOLOGICO", "MATERIAL P/ UTILIZACAO EM GRAFICA", "FERRAMENTAS", "MATERIAL P/ REABILITACAO PROFISSIONAL", "MATERIAL DE SINALIZACAO VISUAL E OUTROS", "MATERIAL TECNICO P/ SELECAO E TREINAMENTO", "MATERIAL BIBLIOGRAFICO", "AQUISICAO DE SOFTWARES DE BASE", "BENS MOVEIS NAO ATIVAVEIS", "BILHETES DE PASSAGEM", "BANDEIRAS, FLAMULAS E INSIGNIAS", "DISCOTECAS E FILMOTECAS NAO IMOBILIZAVEL", "MATERIAL DE CARATER SECRETO OU RESERVADO", "MATERIAL METEOROLOGICO", "MATERIAL P/MANUT.CONSERV.DE ESTRADAS E VIAS", "SELOS PARA CONTROLE FISCAL", "MATERIAL DE CONSUMO - PAGTO ANTECIPADO" }));

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox7, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34)
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 8, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel13)
                        .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel14)
                        .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3)
                        .addComponent(jComboBox7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(77, 77, 77)
                .addComponent(jLabel8)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jButton28.setText("Gerar PDF");
        jButton28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton28ActionPerformed(evt);
            }
        });

        jLabel18.setText("| Estoque");

        jLabel22.setText("| Período de Entrada");

        jLabel27.setText("| Período de Saida");

        jLabel31.setText("| Estoque");

        jButton29.setText("Efetuar buscas");
        jButton29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton29ActionPerformed(evt);
            }
        });

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "#", "Nome", "Qtd.", "Valor Médio", "Valor", "Qtd.", "Valor Médio", "Valor", "Qtd.", "Valor Médio", "Valor", "Qtd.", "Valor Médio", "Valor"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.String.class, java.lang.Integer.class, java.lang.Float.class, java.lang.Float.class, java.lang.Integer.class, java.lang.Float.class, java.lang.Float.class, java.lang.Integer.class, java.lang.Float.class, java.lang.Float.class, java.lang.Integer.class, java.lang.Float.class, java.lang.Float.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane8.setViewportView(jTable2);

        jLabel32.setText("##/##/####");

        jLabel33.setText("##/##/####");

        javax.swing.GroupLayout MovimentaçãoMensalLayout = new javax.swing.GroupLayout(MovimentaçãoMensal);
        MovimentaçãoMensal.setLayout(MovimentaçãoMensalLayout);
        MovimentaçãoMensalLayout.setHorizontalGroup(
            MovimentaçãoMensalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MovimentaçãoMensalLayout.createSequentialGroup()
                .addGroup(MovimentaçãoMensalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(MovimentaçãoMensalLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MovimentaçãoMensalLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane8))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MovimentaçãoMensalLayout.createSequentialGroup()
                        .addGap(154, 154, 154)
                        .addComponent(jLabel18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel33)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel22)
                        .addGap(115, 115, 115)
                        .addComponent(jLabel27)
                        .addGap(128, 128, 128)
                        .addComponent(jLabel31)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel32)
                        .addGap(93, 93, 93)))
                .addContainerGap())
            .addGroup(MovimentaçãoMensalLayout.createSequentialGroup()
                .addGroup(MovimentaçãoMensalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(MovimentaçãoMensalLayout.createSequentialGroup()
                        .addGap(397, 397, 397)
                        .addComponent(jButton28, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(MovimentaçãoMensalLayout.createSequentialGroup()
                        .addGap(398, 398, 398)
                        .addComponent(jButton29, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        MovimentaçãoMensalLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jButton28, jButton29});

        MovimentaçãoMensalLayout.setVerticalGroup(
            MovimentaçãoMensalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MovimentaçãoMensalLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton29)
                .addGap(32, 32, 32)
                .addGroup(MovimentaçãoMensalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel31)
                    .addComponent(jLabel27)
                    .addComponent(jLabel22)
                    .addComponent(jLabel18)
                    .addComponent(jLabel32)
                    .addComponent(jLabel33))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton28)
                .addContainerGap(178, Short.MAX_VALUE))
        );

        Principal.add(MovimentaçãoMensal, "RelatorioMensal");

        IFOpcoes.getContentPane().add(Principal, java.awt.BorderLayout.CENTER);

        mInicio.setText("Início");
        mInicio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mInicioMouseClicked(evt);
            }
        });
        jMenuBar2.add(mInicio);

        mCad.setText("Cadastro");

        mCadPessoa.setText("Pessoa");
        mCadPessoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mCadPessoaActionPerformed(evt);
            }
        });
        mCad.add(mCadPessoa);

        mCadCadEmpenho.setText("Empenho");
        mCadCadEmpenho.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mCadCadEmpenhoActionPerformed(evt);
            }
        });
        mCad.add(mCadCadEmpenho);

        jMenuBar2.add(mCad);

        mConsulta.setText("Consultas");

        mConsultaPessoa.setText("Pessoa");
        mConsultaPessoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mConsultaPessoaActionPerformed(evt);
            }
        });
        mConsulta.add(mConsultaPessoa);

        mConsultaEmpenho.setText("Empenho");
        mConsultaEmpenho.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mConsultaEmpenhoActionPerformed(evt);
            }
        });
        mConsulta.add(mConsultaEmpenho);

        mBuscarEntradas.setText("Entrada");
        mBuscarEntradas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mBuscarEntradasActionPerformed(evt);
            }
        });
        mConsulta.add(mBuscarEntradas);

        mConsultaEstoque.setText("Estoque");
        mConsultaEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mConsultaEstoqueActionPerformed(evt);
            }
        });
        mConsulta.add(mConsultaEstoque);

        jMenuBar2.add(mConsulta);

        mMov.setText("Movimentação");

        mMovEntrada.setText("Entrada");
        mMovEntrada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mMovEntradaActionPerformed(evt);
            }
        });
        mMov.add(mMovEntrada);

        mMovBuscas.setText("Saidas");
        mMovBuscas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mMovBuscasActionPerformed(evt);
            }
        });
        mMov.add(mMovBuscas);

        mRelatorioMensal.setText("Mensal");
        mRelatorioMensal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mRelatorioMensalActionPerformed(evt);
            }
        });
        mMov.add(mRelatorioMensal);

        jMenuBar2.add(mMov);

        IFOpcoes.setJMenuBar(jMenuBar2);

        javax.swing.GroupLayout PainelInferiorOpcoesLayout = new javax.swing.GroupLayout(PainelInferiorOpcoes);
        PainelInferiorOpcoes.setLayout(PainelInferiorOpcoesLayout);
        PainelInferiorOpcoesLayout.setHorizontalGroup(
            PainelInferiorOpcoesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(IFOpcoes, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        PainelInferiorOpcoesLayout.setVerticalGroup(
            PainelInferiorOpcoesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PainelInferiorOpcoesLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(IFOpcoes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PainelSuperiorDados, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(PainelInferiorOpcoes, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(PainelSuperiorDados, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(PainelInferiorOpcoes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void mConsultaEmpenhoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mConsultaEmpenhoActionPerformed
        btnGroupBuscaEmpenho.clearSelection();
        tPeriodoInicial.setText(""); tPeriodoFinal.setText("");// PERIODO INICIAL AO FINAL DE PESQUISA
        tFornecedor.setText(""); // FORNECEDOR
        tNumeroEmpenho.setText(""); // NÚMERO DO EMPENHO
        
        CardLayout card = (CardLayout) Principal.getLayout();       
        card.show(Principal, "ConsultaEmpenho");
    }//GEN-LAST:event_mConsultaEmpenhoActionPerformed

    private void mMovEntradaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mMovEntradaActionPerformed
        jFormattedTextField1.setText("");
        jTextField19.setText("");
        jTextField20.setText("");
        jTextField21.setText("");
        jFormattedTextField2.setText("");
        jComboBox9.setSelectedIndex(0);
        
        CardLayout card = (CardLayout) Principal.getLayout();       
        card.show(Principal, "MovimentacaoEntrada");
    }//GEN-LAST:event_mMovEntradaActionPerformed

    private void mCadPessoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mCadPessoaActionPerformed
        lNome.setVisible(false);
        tfNomeDono.setVisible(false);
        LSexo.setVisible(false);
        rbFeminino.setVisible(false);
        rbMasculino.setVisible(false);
        lCpf.setVisible(false);
        tfCpf.setVisible(false);
        lDataNasc.setVisible(false);
        tfDataNasc.setVisible(false);
        lNomeEmpresa.setVisible(false);
        tfNomeEmpresa.setVisible(false);
        lCnpj.setVisible(false);
        ftfCnpj.setVisible(false);
        lTelefone.setVisible(false);
        ftfTelefone.setVisible(false);
        lWebSite.setVisible(false);
        tfWebSite.setVisible(false);
        lInscricaoEstadual.setVisible(false);
        tfInscricaoEstadual.setVisible(false);
        lEmail.setVisible(false);
        tfEmail.setVisible(false);
        btnGrupTipoPessoa.clearSelection();
        
        tfNomeDono.setText("");
        rbFeminino.setSelected(false);
        rbMasculino.setSelected(false);
        tfCpf.setText("");
        tfDataNasc.setText("");
        tfNomeEmpresa.setText("");
        ftfCnpj.setText("");
        ftfTelefone.setText("");
        tfWebSite.setText("");
        tfInscricaoEstadual.setText("");
        tfEmail.setText("");
        
        CardLayout card = (CardLayout) Principal.getLayout();       
        card.show(Principal, "CadPessoa");
    }//GEN-LAST:event_mCadPessoaActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        jComboBox1.getSelectedIndex(); // TIPO DE MATERIAL
        jTextField1.getText(); // FORNECEDOR
        jTextField2.getText(); // PERIODO DE _____
        jTextField3.getText(); // ATE ____
        jTextField11.getText(); // PROCESSO
        jLabel44.setText(null); // COLOCAR A QUANTIDADE DE RESULTADOS QUE BATEM
               
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField5ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jComboBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox3ActionPerformed

    private void jTextField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField8ActionPerformed

    private void jComboBox4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox4ActionPerformed

    private void opEntradaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opEntradaActionPerformed
        
    }//GEN-LAST:event_opEntradaActionPerformed

    private void opSaidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opSaidaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_opSaidaActionPerformed

    private void opAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opAllActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_opAllActionPerformed

    private void tPeriodoInicialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tPeriodoInicialActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tPeriodoInicialActionPerformed

    private void tPeriodoFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tPeriodoFinalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tPeriodoFinalActionPerformed

    private void bPrintAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPrintAllActionPerformed
        bPrintAll.setEnabled(false);
    }//GEN-LAST:event_bPrintAllActionPerformed

    private void bPrintSelecionadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPrintSelecionadoActionPerformed
          try {
                relatorioEmpenho.geraPDFEmpenho();
            } catch (FileNotFoundException ex) {
                Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            
            } catch (IOException ex) {
                Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            } catch (BadElementException ex) {
                Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_bPrintSelecionadoActionPerformed

    private void tNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tNomeActionPerformed

    private void tCodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tCodigoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tCodigoActionPerformed

    private void bPrintAll1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPrintAll1ActionPerformed
        bPrintAll.setEnabled(false);
    }//GEN-LAST:event_bPrintAll1ActionPerformed

    private void bPrintSelecionado1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPrintSelecionado1ActionPerformed
        try {
                relatorioEstoque.geraPDFEstoque();
            } catch (FileNotFoundException ex) {
                Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            
            } catch (IOException ex) {
                Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            } catch (BadElementException ex) {
                Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_bPrintSelecionado1ActionPerformed

    private void opPFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opPFActionPerformed
        lBuscarNome.setVisible(true);
        tfBuscaNome.setVisible(true);
        lBuscarCnpj.setVisible(false);
        ftfBuscarCnpj.setVisible(false);
        lCPF.setVisible(true);
        ftfBuscarCpf.setVisible(true);
        labelCPFeCNPJ2.setVisible(false);
        ftfBuscarCnpjECpf.setVisible(false);
    }//GEN-LAST:event_opPFActionPerformed

    private void opPJActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opPJActionPerformed
        lBuscarNome.setVisible(true);
        tfBuscaNome.setVisible(true);
        lBuscarCnpj.setVisible(true);
        ftfBuscarCnpj.setVisible(true);
        lCPF.setVisible(false);
        ftfBuscarCpf.setVisible(false);
        labelCPFeCNPJ2.setVisible(false);
        ftfBuscarCnpjECpf.setVisible(false);
    }//GEN-LAST:event_opPJActionPerformed

    private void bPrintAll2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPrintAll2ActionPerformed
        bPrintAll.setEnabled(false);
    }//GEN-LAST:event_bPrintAll2ActionPerformed

    private void bPrintSelecionado2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPrintSelecionado2ActionPerformed
        if(opPF.isSelected()){
            try {
                relatorioPessoa.geraPDFPessoaFisisca();
            } catch (FileNotFoundException ex) {
                Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            
            } catch (IOException ex) {
                Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            } catch (BadElementException ex) {
                Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else{
            if(opPJ.isSelected()){
                 try {
                relatorioPessoa.geraPDFPessoaJuridica();
            } catch (FileNotFoundException ex) {
                Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            
            } catch (IOException ex) {
                Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            }   catch (BadElementException ex) {
                    Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }//GEN-LAST:event_bPrintSelecionado2ActionPerformed

    private void mInicioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mInicioMouseClicked
        CardLayout card = (CardLayout) Principal.getLayout();       
        card.show(Principal, "Inicio");
    }//GEN-LAST:event_mInicioMouseClicked

    private void mCadCadEmpenhoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mCadCadEmpenhoActionPerformed
        btnGroupBuscaEmpenho.clearSelection();
        jTextField4.setText("");
        jTextField5.setText("");
        jTextField10.setText("");
        jTextArea3.setText("");
        tfCadEmpNome.setText("");
        tflCadEmpNomeEmpresa.setText("");
        ftfDataReceb.setText("");
        jTextField8.setText("");
        jComboBox5.setSelectedIndex(0);
        cadEmpenho_Obs.setText("");
        jTextField12.setText("");
        jTextField13.setText("");
        CardLayout card = (CardLayout) Principal.getLayout();       
        card.show(Principal, "CadEmpenho");
        empenho = new Empenho(null, null, null, SOMEBITS, rootPaneCheckingEnabled, null, null, null, ALLBITS, ALLBITS, null);
    }//GEN-LAST:event_mCadCadEmpenhoActionPerformed

    private void mConsultaPessoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mConsultaPessoaActionPerformed
        lBuscarNome.setVisible(false);
        tfBuscaNome.setVisible(false);
        lBuscarCnpj.setVisible(false);
        ftfBuscarCnpj.setVisible(false);
        lCPF.setVisible(false);
        ftfBuscarCpf.setVisible(false);
        labelCPFeCNPJ2.setVisible(false);
        ftfBuscarCnpjECpf.setVisible(false);
        btnGroupBuscaPessoa.clearSelection();
        tfBuscaNome.setText("");  //BUSCAR NOME
        ftfBuscarCpf.setText(""); //BUSCAR CPF
        ftfBuscarCnpj.setText("");    //BUSCAR CNPJ
        ftfBuscarCnpjECpf.setText("");   //BUSCAR CNPJ CASO A OPÇÃO PESSOA FÍSICA/JURIDICA ESTIVER SELECIONADA
        CardLayout card = (CardLayout) Principal.getLayout();       
        card.show(Principal, "ConsultaPessoa");
    }//GEN-LAST:event_mConsultaPessoaActionPerformed

    private void mConsultaEstoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mConsultaEstoqueActionPerformed
        ListaItens.setSelectedIndex(0);
        tNome.setText("");
        tCodigo.setText("");
        
        CardLayout card = (CardLayout) Principal.getLayout();       
        card.show(Principal, "ConsultaEstoque");
    }//GEN-LAST:event_mConsultaEstoqueActionPerformed

    private void mRelatorioMensalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mRelatorioMensalActionPerformed
        jComboBox7.setSelectedIndex(0); //ELEMENTO DE DESPESA
        jTextField7.setText(""); /*PERIODO DE*/
        jTextField9.setText(""); /* ATE */ 
        
        CardLayout card = (CardLayout) Principal.getLayout();       
        card.show(Principal, "RelatorioMensal");
    }//GEN-LAST:event_mRelatorioMensalActionPerformed

    private void mMovBuscasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mMovBuscasActionPerformed
        jComboBox10.setSelectedIndex(0); // CATEGORIA SELECIONADA
        jTextField16.setText(""); // NOME SELECIONADO
        jTextField17.setText(""); // QUANTIDADE
        
        CardLayout card = (CardLayout) Principal.getLayout();       
        card.show(Principal, "MovimentacaoSaida");
    }//GEN-LAST:event_mMovBuscasActionPerformed

    private void jTextField12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField12ActionPerformed
        
    }//GEN-LAST:event_jTextField12ActionPerformed

    private void rbFemininoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbFemininoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbFemininoActionPerformed

    private void ftfCnpjActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ftfCnpjActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ftfCnpjActionPerformed

    private void rbPessoaFisicaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbPessoaFisicaActionPerformed
        if(rbPessoaFisica.isSelected()){
            pessoa = new Pessoa(rootPaneCheckingEnabled, null, rootPaneCheckingEnabled, null, null);
            lNome.setVisible(true);
            tfNomeDono.setVisible(true);
            LSexo.setVisible(true);
            rbFeminino.setVisible(true);
            rbMasculino.setVisible(true);
            lCpf.setVisible(true);
            tfCpf.setVisible(true);
            lDataNasc.setVisible(true);
            tfDataNasc.setVisible(true);
            
            lNomeEmpresa.setVisible(false);
            tfNomeEmpresa.setVisible(false);
            lCnpj.setVisible(false);
            ftfCnpj.setVisible(false);
            lTelefone.setVisible(false);
            ftfTelefone.setVisible(false);
            lWebSite.setVisible(false);
            tfWebSite.setVisible(false);
            lInscricaoEstadual.setVisible(false);
            tfInscricaoEstadual.setVisible(false);
            lEmail.setVisible(false);
            tfEmail.setVisible(false);
        }
    }//GEN-LAST:event_rbPessoaFisicaActionPerformed

    private void rbPessoaJuridicaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbPessoaJuridicaActionPerformed
         if(rbPessoaJuridica.isSelected()){
            pessoa = new Pessoa(rootPaneCheckingEnabled, null, null, null, null, null, null, null);
            lNome.setVisible(true);
            tfNomeDono.setVisible(true);
            LSexo.setVisible(false);
            rbFeminino.setVisible(false);
            rbMasculino.setVisible(false);
            lCpf.setVisible(false);
            tfCpf.setVisible(false);
            lDataNasc.setVisible(false);
            tfDataNasc.setVisible(false);
            lNomeEmpresa.setVisible(true);
            
            tfNomeEmpresa.setVisible(true);
            lCnpj.setVisible(true);
            ftfCnpj.setVisible(true);
            lTelefone.setVisible(true);
            ftfTelefone.setVisible(true);
            lWebSite.setVisible(true);
            tfWebSite.setVisible(true);
            lInscricaoEstadual.setVisible(true);
            tfInscricaoEstadual.setVisible(true);
            lEmail.setVisible(true);
            tfEmail.setVisible(true);
        }
    }//GEN-LAST:event_rbPessoaJuridicaActionPerformed

    private void mBuscarEntradasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mBuscarEntradasActionPerformed
        jComboBox1.setSelectedIndex(0); // TIPO DE MATERIAL
        jTextField1.setText(""); // FORNECEDOR
        jTextField2.setText(""); // PERIODO DE _____
        jTextField3.setText("");// ATE ____
        jTextField11.setText(""); // PROCESSO
        CardLayout card = (CardLayout) Principal.getLayout();       
        card.show(Principal, "BuscaEntradas");
    }//GEN-LAST:event_mBuscarEntradasActionPerformed

    private void jRadioButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton2ActionPerformed
       lCadEmpNome.setVisible(true);
       tfCadEmpNome.setVisible(true);
       lCadEmpNomeEmpresa.setVisible(false);
       tflCadEmpNomeEmpresa.setVisible(false);
    }//GEN-LAST:event_jRadioButton2ActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
         lCadEmpNome.setVisible(false);
       tfCadEmpNome.setVisible(false);
       lCadEmpNomeEmpresa.setVisible(true);
       tflCadEmpNomeEmpresa.setVisible(true);
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        jComboBox10.getSelectedIndex(); // CATEGORIA SELECIONADA
        jTextField16.getText(); // NOME SELECIONADO
        jTextField17.getText(); // QUANTIDADE
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jTextField13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField13ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        itens = new Itens(i, null, i, TOP_ALIGNMENT);
       
        if((!jTextField12.getText().isEmpty()) && !jTextField13.getText().isEmpty()){
            itens.setCategoria(jComboBox5.getSelectedIndex());
            itens.setDesc(cadEmpenho_Obs.getText());
            itens.setQuantidade(Integer.parseInt(jTextField12.getText()));
            itens.setValor(Float.parseFloat(jTextField13.getText()));
            jComboBox5.setSelectedIndex(0);
            cadEmpenho_Obs.setText("");
            jTextField12.setText("");
            jTextField13.setText("");
        } else {
            JOptionPane.showMessageDialog(null, "Todos os campos obrigatórios devem ser preenchidos.");
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jComboBox5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox5ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        if((jTextField4.getText()!="") && (jTextField5.getText()!="") && (jTextField10.getText()!="")
                && (jTextArea3.getText()!="") && ((tfCadEmpNome.getText()!="") || (tflCadEmpNomeEmpresa.getText()!="")) && 
                (jRadioButton2.isSelected() || jRadioButton1.isSelected()) && (ftfDataReceb.getText()!="") && (jTextField8.getText()!="")){
            empenho.setNumeroEmpenho(jTextField4.getText());
            empenho.setProcesso(jTextField5.getText());
            empenho.setNumeroLicitacao(Integer.parseInt(jTextField10.getText()));
            empenho.setObs(jTextArea3.getText());
            if(jRadioButton2.isSelected())
                empenho.setNome(tfCadEmpNome.getText());
            if(jRadioButton1.isSelected())
                empenho.setNome(tflCadEmpNomeEmpresa.getText());
            empenho.setRecebimento(ftfDataReceb.getText());
            empenho.setPrazo(jTextField8.getText());
            JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso");
            jTextField4.setText("");
            jTextField5.setText("");
            tfCadEmpNome.setText("");
            jRadioButton2.setSelected(false);
            jRadioButton1.setSelected(false);
            tfCadEmpNome.setText("");
            ftfDataReceb.setText("");
            jTextField8.setText("");
            jTextField10.setText("");
            jTextArea3.setText("");
            cadEmpenho_Obs.setText("");
            jTextField12.setText("");
            jTextField13.setText("");
            btnGrupTipoPessoa.clearSelection();
            jComboBox3.setSelectedIndex(0);
            jComboBox2.setSelectedIndex(0);
            jComboBox4.setSelectedIndex(0);
        } else JOptionPane.showMessageDialog(null, "Todos os campos obrigatórios devem ser preenchidos");
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        if((tfNomeDono.getText()!="") && (((tfNomeEmpresa.getText()!="") && (tfEmail.getText()!="") && (tfWebSite.getText()!="") && 
                (ftfCnpj.getText()!="") && (ftfTelefone.getText()!="") && (tfInscricaoEstadual.getText()!="")) || ((rbFeminino.isSelected())
                || rbMasculino.isSelected()) && (tfCpf.getText()!="") && (tfDataNasc.getText()!=""))){
            if(rbPessoaFisica.isSelected()){
                pessoa.setNome(tfNomeDono.getText());
                if(rbFeminino.isSelected())
                    pessoa.setSexo(false);
                if(rbMasculino.isSelected())
                    pessoa.setSexo(true);
                pessoa.setCpf(tfCpf.getText());
                pessoa.setNascimento(tfDataNasc.getText());
                JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso");
            }else
            if(rbPessoaJuridica.isSelected()){
                pessoa.setDono(tfNomeDono.getText());
                pessoa.setNomeFicticio(tfNomeEmpresa.getText());
                pessoa.setEmail(tfEmail.getText());
                pessoa.setWebsite(tfWebSite.getText());
                pessoa.setCnpj(ftfCnpj.getText());
                pessoa.setFone(ftfTelefone.getText());
                pessoa.setInscricaoEstadual(tfInscricaoEstadual.getText());
                JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso");
                CardLayout card = (CardLayout) Principal.getLayout();
                card.show(Principal, "Inicio");
            } else {
                JOptionPane.showMessageDialog(null, "O tipo de pessoa deve ser definido.");
            }
            
        }
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        jTextField4.setText("");
        jTextField5.setText("");
        tfCadEmpNome.setText("");
        jRadioButton2.setSelected(false);
        jRadioButton1.setSelected(false);
        tfCadEmpNome.setText("");
        ftfDataReceb.setText("");
        jTextField8.setText("");
        jTextField10.setText("");
        jTextArea3.setText("");
        cadEmpenho_Obs.setText("");
        jTextField12.setText("");
        jTextField13.setText("");
        jComboBox3.setSelectedIndex(0);
        jComboBox2.setSelectedIndex(0);
        jComboBox4.setSelectedIndex(0);
        jComboBox5.setSelectedIndex(0);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        
        if((!jFormattedTextField1.getText().isEmpty()) && (!jTextField19.getText().isEmpty()) && (!jTextField20.getText().isEmpty())
                && (!jTextField21.getText().isEmpty()) && (!jFormattedTextField2.getText().isEmpty())){
            CardLayout card = (CardLayout) Principal.getLayout();       
            card.show(Principal, "ResumoEntrada");
        } else {
            JOptionPane.showMessageDialog(null, "Todos os campos devem ser preenchidos para gerar uma entrada");
        }
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jFormattedTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jFormattedTextField1ActionPerformed
        jFormattedTextField1.getText();
    }//GEN-LAST:event_jFormattedTextField1ActionPerformed

    private void jComboBox9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox9ActionPerformed
        jComboBox9.getSelectedIndex();
    }//GEN-LAST:event_jComboBox9ActionPerformed

    private void jTextField19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField19ActionPerformed
        jTextField19.getText();
    }//GEN-LAST:event_jTextField19ActionPerformed

    private void jTextField20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField20ActionPerformed
        jTextField20.getText();
    }//GEN-LAST:event_jTextField20ActionPerformed

    private void jTextField21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField21ActionPerformed
        jTextField21.getText();
    }//GEN-LAST:event_jTextField21ActionPerformed

    private void jFormattedTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jFormattedTextField2ActionPerformed
        jFormattedTextField2.getText();
    }//GEN-LAST:event_jFormattedTextField2ActionPerformed

    private void buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarActionPerformed
        opEntrada.isSelected(); // NECESSÁRIO COMPARAR COM O BANCO DE DADOS
        opSaida.isSelected(); // NECESSÁRIO COMPARAR COM O BANCO DE DADOS
        opAll.isSelected(); // NECESSÁRIO COMPARAR COM O BANCO DE DADOS
        
        tPeriodoInicial.getText(); tPeriodoFinal.getText(); // PERIODO INICIAL AO FINAL DE PESQUISA
        tFornecedor.getText(); // FORNECEDOR
        tNumeroEmpenho.getText(); // NÚMERO DO EMPENHO
    }//GEN-LAST:event_buscarActionPerformed

    private void BuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarActionPerformed
        ListaItens.getSelectedIndex();
        tNome.getText();
        tCodigo.getText();
    }//GEN-LAST:event_BuscarActionPerformed

    private void buscar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscar1ActionPerformed

        opPF.isSelected();  // COMPARAR NO BANCO DE DADOS
        opPJ.isSelected();  // COMPARAR NO BANCO DE DADOS
        tfBuscaNome.getText();  //BUSCAR NOME
        ftfBuscarCpf.getText(); //BUSCAR CPF
        ftfBuscarCnpj.getText();    //BUSCAR CNPJ

    }//GEN-LAST:event_buscar1ActionPerformed

    private void jComboBox10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox10ActionPerformed
        
    }//GEN-LAST:event_jComboBox10ActionPerformed

    private void jTextField16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField16ActionPerformed
        
    }//GEN-LAST:event_jTextField16ActionPerformed

    private void jTextField17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField17ActionPerformed
        
    }//GEN-LAST:event_jTextField17ActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
        JOptionPane.showConfirmDialog(null, "Tem certeza que deseja excluir esses itens?"); //CONFIRMAÇÃO SE DESEJA DELETAR OS ITENS SELECIONADOS
    }//GEN-LAST:event_jButton20ActionPerformed

    private void jButton29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton29ActionPerformed
        jComboBox7.getSelectedIndex(); //ELEMENTO DE PESQUISA
        jTextField7.getText(); /*PERIODO DE*/
        jTextField9.getText(); /* ATE */ 
    }//GEN-LAST:event_jButton29ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        btnGrupTipoPessoa.clearSelection();
        tfNomeDono.setText("");
        tfNomeEmpresa.setText("");
        tfEmail.setText("");
        tfWebSite.setText("");
        ftfCnpj.setText("");
        ftfTelefone.setText("");
        tfInscricaoEstadual.setText("");
        btnGroupSexoPessoa.clearSelection();
        tfCpf.setText("");
        tfDataNasc.setText("");
        
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        if((tfNomeDono.getText()!="") && (((tfNomeEmpresa.getText()!="") && (tfEmail.getText()!="") && (tfWebSite.getText()!="") && 
                (ftfCnpj.getText()!="") && (ftfTelefone.getText()!="") && (tfInscricaoEstadual.getText()!="")) || ((rbFeminino.isSelected())
                || rbMasculino.isSelected()) && (tfCpf.getText()!="") && (tfDataNasc.getText()!=""))){
            if(rbPessoaFisica.isSelected()){
                pessoa.setNome(tfNomeDono.getText());
                if(rbFeminino.isSelected())
                    pessoa.setSexo(false);
                if(rbMasculino.isSelected())
                    pessoa.setSexo(true);
                pessoa.setCpf(tfCpf.getText());
                pessoa.setNascimento(tfDataNasc.getText());
                btnGroupSexoPessoa.clearSelection();
                tfNomeDono.setText("");
                tfCpf.setText("");
                tfDataNasc.setText("");
            }else
            if(rbPessoaJuridica.isSelected()){
                pessoa.setDono(tfNomeDono.getText());
                pessoa.setNomeFicticio(tfNomeEmpresa.getText());
                pessoa.setEmail(tfEmail.getText());
                pessoa.setWebsite(tfWebSite.getText());
                pessoa.setCnpj(ftfCnpj.getText());
                pessoa.setFone(ftfTelefone.getText());
                pessoa.setInscricaoEstadual(tfInscricaoEstadual.getText());
                tfNomeDono.setText("");
                tfNomeEmpresa.setText("");
                tfEmail.setText("");
                tfWebSite.setText("");
                ftfCnpj.setText("");
                ftfTelefone.setText("");
                tfInscricaoEstadual.setText("");
                JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso");
            } else {
                JOptionPane.showMessageDialog(null, "O tipo de pessoa deve ser definido");
            }
        }
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        CardLayout card = (CardLayout) Principal.getLayout();       
        card.show(Principal, "Inicio");
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        CardLayout card = (CardLayout) Principal.getLayout();       
        card.show(Principal, "Inicio");
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton27ActionPerformed
        CardLayout card = (CardLayout) Principal.getLayout();       
        card.show(Principal, "MovimentacaoEntrada");
    }//GEN-LAST:event_jButton27ActionPerformed

    private void jButton24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton24ActionPerformed
        jFormattedTextField1.setText("");
        jComboBox9.setSelectedIndex(0);
        jTextField19.setText("");
        jTextField20.setText("");
        jTextField21.setText("");
        jFormattedTextField2.setText("");
        CardLayout card = (CardLayout) Principal.getLayout();       
        card.show(Principal, "MovimentacaoEntrada");
        
    }//GEN-LAST:event_jButton24ActionPerformed

    private void jButton28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton28ActionPerformed
        try {
                relatorioMensal.geraPDFMensal();
            } catch (FileNotFoundException ex) {
                Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            
            } catch (IOException ex) {
                Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            } catch (BadElementException ex) {
                Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_jButton28ActionPerformed

    private void jButton26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton26ActionPerformed
        try {
                relatorioEntrada.geraPDFEntrada();
            } catch (FileNotFoundException ex) {
                Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            
            } catch (IOException ex) {
                Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            } catch (BadElementException ex) {
                Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_jButton26ActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
        try {
                relatorioSaida.geraPDFSaida();
            } catch (FileNotFoundException ex) {
                Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            
            } catch (IOException ex) {
                Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            } catch (BadElementException ex) {
                Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_jButton21ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel BuscaEntradas;
    private javax.swing.JButton Buscar;
    private javax.swing.JPanel CadEmpenho;
    private javax.swing.JPanel CadPessoa;
    private javax.swing.JPanel ConsultaEmpenho;
    private javax.swing.JPanel ConsultaEstoque;
    private javax.swing.JPanel ConsultaPessoa;
    private javax.swing.JPanel Foto;
    private javax.swing.JInternalFrame IFOpcoes;
    private javax.swing.JPanel Inicio;
    private javax.swing.JLabel LSexo;
    private javax.swing.JComboBox<String> ListaItens;
    private javax.swing.JPanel MovimentacaoEntrada;
    private javax.swing.JPanel MovimentacaoSaida;
    private javax.swing.JPanel MovimentaçãoMensal;
    private javax.swing.JLabel NomeUsuario;
    private javax.swing.JLabel OpSair;
    private javax.swing.JPanel PainelInferiorOpcoes;
    private javax.swing.JPanel PainelSuperiorDados;
    private javax.swing.JPanel Principal;
    private javax.swing.JPanel ResumoEntrada;
    private javax.swing.JLabel Titulo;
    private javax.swing.JLabel a;
    private javax.swing.JButton bPrintAll;
    private javax.swing.JButton bPrintAll1;
    private javax.swing.JButton bPrintAll2;
    private javax.swing.JButton bPrintSelecionado;
    private javax.swing.JButton bPrintSelecionado1;
    private javax.swing.JButton bPrintSelecionado2;
    private javax.swing.ButtonGroup btnGroupBuscaEmpenho;
    private javax.swing.ButtonGroup btnGroupBuscaPessoa;
    private javax.swing.ButtonGroup btnGroupSexoPessoa;
    private javax.swing.ButtonGroup btnGrupTipoFornecedor;
    private javax.swing.ButtonGroup btnGrupTipoPessoa;
    private javax.swing.JButton buscar;
    private javax.swing.JButton buscar1;
    private javax.swing.JTextArea cadEmpenho_Obs;
    private javax.swing.JFormattedTextField ftfBuscarCnpj;
    private javax.swing.JFormattedTextField ftfBuscarCnpjECpf;
    private javax.swing.JFormattedTextField ftfBuscarCpf;
    private javax.swing.JFormattedTextField ftfCnpj;
    private javax.swing.JFormattedTextField ftfDataReceb;
    private javax.swing.JFormattedTextField ftfTelefone;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton27;
    private javax.swing.JButton jButton28;
    private javax.swing.JButton jButton29;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox10;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JComboBox<String> jComboBox5;
    private javax.swing.JComboBox<String> jComboBox7;
    private javax.swing.JComboBox jComboBox8;
    private javax.swing.JComboBox<String> jComboBox9;
    private javax.swing.JFormattedTextField jFormattedTextField1;
    private javax.swing.JFormattedTextField jFormattedTextField2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    private javax.swing.JTextArea jTextArea3;
    private javax.swing.JTextArea jTextArea4;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JTextField jTextField17;
    private javax.swing.JTextField jTextField19;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField20;
    private javax.swing.JTextField jTextField21;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JLabel lBuscarCnpj;
    private javax.swing.JLabel lBuscarNome;
    private javax.swing.JLabel lCPF;
    private javax.swing.JLabel lCadEmpNome;
    private javax.swing.JLabel lCadEmpNomeEmpresa;
    private javax.swing.JLabel lCnpj;
    private javax.swing.JLabel lCpf;
    private javax.swing.JLabel lDataNasc;
    private javax.swing.JLabel lEmail;
    private javax.swing.JLabel lInscricaoEstadual;
    private javax.swing.JLabel lNome;
    private javax.swing.JLabel lNomeEmpresa;
    private javax.swing.JLabel lTelefone;
    private javax.swing.JLabel lWebSite;
    private javax.swing.JLabel labelCPFeCNPJ2;
    private javax.swing.JLabel labelFornecedor;
    private javax.swing.JLabel labelNome;
    private javax.swing.JLabel labelNome1;
    private javax.swing.JLabel labelNumeroEmpenho;
    private javax.swing.JMenuItem mBuscarEntradas;
    private javax.swing.JMenu mCad;
    private javax.swing.JMenuItem mCadCadEmpenho;
    private javax.swing.JMenuItem mCadPessoa;
    private javax.swing.JMenu mConsulta;
    private javax.swing.JMenuItem mConsultaEmpenho;
    private javax.swing.JMenuItem mConsultaEstoque;
    private javax.swing.JMenuItem mConsultaPessoa;
    private javax.swing.JMenu mInicio;
    private javax.swing.JMenu mMov;
    private javax.swing.JMenuItem mMovBuscas;
    private javax.swing.JMenuItem mMovEntrada;
    private javax.swing.JMenuItem mRelatorioMensal;
    private javax.swing.JRadioButton opAll;
    private javax.swing.JRadioButton opEntrada;
    private javax.swing.JRadioButton opPF;
    private javax.swing.JRadioButton opPJ;
    private javax.swing.JRadioButton opSaida;
    private javax.swing.JRadioButton rbFeminino;
    private javax.swing.JRadioButton rbMasculino;
    private javax.swing.JRadioButton rbPessoaFisica;
    private javax.swing.JRadioButton rbPessoaJuridica;
    private javax.swing.JScrollPane scroll;
    private javax.swing.JScrollPane scroll1;
    private javax.swing.JSeparator separador1;
    private javax.swing.JTextField tCodigo;
    private javax.swing.JTextField tFornecedor;
    private javax.swing.JTextField tNome;
    private javax.swing.JTextField tNumeroEmpenho;
    private javax.swing.JTextField tPeriodoFinal;
    private javax.swing.JTextField tPeriodoInicial;
    private javax.swing.JTable tabela;
    private javax.swing.JTable tabela1;
    private javax.swing.JTable tabela2;
    private javax.swing.JTextField tfBuscaNome;
    private javax.swing.JTextField tfCadEmpNome;
    private javax.swing.JTextField tfCpf;
    private javax.swing.JTextField tfDataNasc;
    private javax.swing.JTextField tfEmail;
    private javax.swing.JTextField tfInscricaoEstadual;
    private javax.swing.JTextField tfNomeDono;
    private javax.swing.JTextField tfNomeEmpresa;
    private javax.swing.JTextField tfWebSite;
    private javax.swing.JTextField tflCadEmpNomeEmpresa;
    // End of variables declaration//GEN-END:variables

}
