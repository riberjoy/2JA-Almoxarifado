package relatorios;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import dao.dataDAO;
import java.awt.Font;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import javax.swing.JOptionPane;


public class relatorioMensal {
    //necessário buscar no banco os dados item referente a pessoa selecionada.
    static String nomeItem = null;
     static String codItem = null;
    
    static String qntEstoqueAnt = null;
    static String valorMedioEstoqueAnt = null;
    static String valorEstoqueAnt = null;
    
    static String qntPeriodoEntrada = null;
    static String valorMedioEntrada = null;
    static String valorEntrada = null;
    
    static String qntPeriodoSaida = null;
    static String valorMedioSaida = null;
    static String valorSaida = null;
    
    static String qntEstoque = null;
    static String valorMedioEstoque = null;
    static String valorEstoque = null;
    
    static String elementoDespesa = null;
    static String pinicio = null;
    static String pfinal = null;
   
    static String estoqueData = null;
    static String pEntrada = null;
    static String psaida = null;
    static String estoqueDataAtual = null;
  
  
     
     public static void geraPDFMensal() throws FileNotFoundException, BadElementException, IOException{
         Document documentoPDF = new Document();
      
        try{
            String dir = System.getProperty("user.home");
            PdfWriter.getInstance(documentoPDF, new FileOutputStream(dir+"\\Documents\\Relatorio_Mensal.pdf"));
            
            documentoPDF.open();
            documentoPDF.setPageSize(PageSize.A4);
            
            Image logoIF = Image.getInstance(dir+"\\Desktop\\Almoxarifado\\logoPdf\\imagemLogo.png");
            logoIF.scaleToFit(50, 50);
            logoIF.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(logoIF);
            
            Paragraph espaco = new Paragraph(" ");
            documentoPDF.add(espaco);
            
            Paragraph pTitulo = new Paragraph(new Phrase(10F , "MINISTÉRIO DA EDUCAÇÃO", FontFactory.getFont(FontFactory.TIMES, 10F, Font.BOLD)));
            pTitulo.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(pTitulo);
            
            Paragraph pTitulo2 = new Paragraph(new Phrase(10F , "Secretaria de Educação Profissional e Tecnológica", FontFactory.getFont(FontFactory.TIMES, 10F, Font.BOLD)));
            pTitulo2.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(pTitulo2);
            
            Paragraph pTitulo3 = new Paragraph(new Phrase(10F , "Instituto Federal de Educação, Ciência e Tecnologia do Sul de Minas Gerais - Campus Passos", FontFactory.getFont(FontFactory.TIMES, 10F, Font.BOLD)));
            pTitulo3.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(pTitulo3);
            
            Paragraph pTitulo4 = new Paragraph(new Phrase(10F , "Rua Mário Ribola, 409, Bairro Penha II , Passos / MG, CEP 37903-358 - Fone: (35) 3526-4856", FontFactory.getFont(FontFactory.TIMES, 10F)));
            pTitulo4.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(pTitulo4);
            
            documentoPDF.add(espaco);
            
            Paragraph tipoPDF = new Paragraph(new Phrase(15F , "Relatorio Mensal", FontFactory.getFont(FontFactory.TIMES, 15F)));
            tipoPDF.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(tipoPDF);
            
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
           

            Paragraph numLici = new Paragraph(new Phrase(12F , "Elemento da despesa: " + elementoDespesa, FontFactory.getFont(FontFactory.TIMES, 12F)));
            documentoPDF.add(numLici);
            documentoPDF.add(espaco);
            
            
            Paragraph obser = new Paragraph(new Phrase(12F , "Periodo de " + pinicio +" à "+pfinal, FontFactory.getFont(FontFactory.TIMES, 12F)));
            documentoPDF.add(obser);
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
            

            PdfPTable tabela = new PdfPTable(13);
            
            PdfPCell cabecalho = new PdfPCell(new Phrase(12F , "Estoque anterior"+estoqueData, FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho.setColspan(4);
            cabecalho.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho);
            
            cabecalho = new PdfPCell(new Phrase(12F , "Periodo entrada", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho.setColspan(3);
            cabecalho.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho);
            
            cabecalho = new PdfPCell(new Phrase(12F , "Periodo saída", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho.setColspan(3);
            cabecalho.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho);
            
            cabecalho = new PdfPCell(new Phrase(12F , "Estoque final", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho.setColspan(3);
            cabecalho.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho);
            
          
            
            PdfPCell cabecalho2 = new PdfPCell(new Phrase(12F , "Nome", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho2.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho2);
            
            PdfPCell cabecalho3 = new PdfPCell(new Phrase(12F , "Qnt", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho3.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho3);
            
            PdfPCell cabecalho4 = new PdfPCell(new Phrase(12F , "Valor médio", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho4.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho4);
            
            PdfPCell cabecalho5 = new PdfPCell(new Phrase(12F , "Valor total", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho5.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho5);
            
             PdfPCell cabecalho6 = new PdfPCell(new Phrase(12F , "Qnt", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho6.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho6);
            
            PdfPCell cabecalho7 = new PdfPCell(new Phrase(12F , "Valor médio", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho7.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho7);
            
            PdfPCell cabecalho8 = new PdfPCell(new Phrase(12F , "Valor total", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho8.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho8);
            
            
             PdfPCell cabecalho9 = new PdfPCell(new Phrase(12F , "Qnt", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho9.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho9);
            
            PdfPCell cabecalho10 = new PdfPCell(new Phrase(12F , "Valor médio", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho10.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho10);
            
            PdfPCell cabecalho11 = new PdfPCell(new Phrase(12F , "Valor total", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho11.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho11);
            
             cabecalho9 = new PdfPCell(new Phrase(12F , "Qnt", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho9.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho9);
            
             cabecalho10 = new PdfPCell(new Phrase(12F , "Valor médio", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho10.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho10);
            
             cabecalho11 = new PdfPCell(new Phrase(12F , "Valor total", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho11.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho11);
            
            int qntItensLista = 0;
            
            //Insere na tabela a lista de itens 
            for(int i=0; i<qntItensLista;i++){
            
                PdfPCell cat = new PdfPCell(new Phrase(12F , nomeItem, FontFactory.getFont(FontFactory.TIMES, 12F)));
                tabela.addCell(cat);

                PdfPCell desc = new PdfPCell(new Phrase(12F ,qntEstoqueAnt, FontFactory.getFont(FontFactory.TIMES, 12F)));
                tabela.addCell(desc);

                PdfPCell qnt = new PdfPCell(new Phrase(12F , valorMedioEstoqueAnt, FontFactory.getFont(FontFactory.TIMES, 12F)));
                tabela.addCell(qnt);

                PdfPCell vT = new PdfPCell(new Phrase(12F , valorEstoqueAnt, FontFactory.getFont(FontFactory.TIMES, 12F)));
                tabela.addCell(vT);
                
                
                desc = new PdfPCell(new Phrase(12F ,qntPeriodoEntrada, FontFactory.getFont(FontFactory.TIMES, 12F)));
                tabela.addCell(desc);

                qnt = new PdfPCell(new Phrase(12F , valorMedioEntrada, FontFactory.getFont(FontFactory.TIMES, 12F)));
                tabela.addCell(qnt);

                vT = new PdfPCell(new Phrase(12F , valorEntrada, FontFactory.getFont(FontFactory.TIMES, 12F)));
                tabela.addCell(vT);
                
                
                desc = new PdfPCell(new Phrase(12F ,qntPeriodoSaida, FontFactory.getFont(FontFactory.TIMES, 12F)));
                tabela.addCell(desc);

                qnt = new PdfPCell(new Phrase(12F , valorMedioSaida, FontFactory.getFont(FontFactory.TIMES, 12F)));
                tabela.addCell(qnt);

                vT = new PdfPCell(new Phrase(12F , valorSaida, FontFactory.getFont(FontFactory.TIMES, 12F)));
                tabela.addCell(vT);
                
                
                desc = new PdfPCell(new Phrase(12F ,qntEstoque, FontFactory.getFont(FontFactory.TIMES, 12F)));
                tabela.addCell(desc);

                qnt = new PdfPCell(new Phrase(12F , valorMedioEstoque, FontFactory.getFont(FontFactory.TIMES, 12F)));
                tabela.addCell(qnt);

                vT = new PdfPCell(new Phrase(12F , valorEstoque, FontFactory.getFont(FontFactory.TIMES, 12F)));
                tabela.addCell(vT);
                
            }
            documentoPDF.add(tabela);
            
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
           
            Paragraph rpd = new Paragraph(new Phrase(15F , "Passos, dia "+Calendar.DAY_OF_MONTH+" de "+ dataDAO.getMes() +" de "+Calendar.YEAR , FontFactory.getFont(FontFactory.TIMES, 15F)));
            rpd.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(rpd);
            
        }catch(DocumentException de){
            de.printStackTrace();
        }catch(IndexOutOfBoundsException ioe){
            ioe.printStackTrace();
        }finally{
            documentoPDF.close();
            JOptionPane.showMessageDialog(null,"Relatório criado com sucesso!");
        }
    }
}
