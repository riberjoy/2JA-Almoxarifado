package relatorios;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import dao.dataDAO;
import java.awt.Font;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import javax.swing.JOptionPane;
import static relatorios.relatorioMensal.estoqueData;

public class relatorioSaida {
    //necessário buscar no banco os dados item referente a pessoa selecionada.
    static String codItem = null;
    static String cat = null;
    static String descricao = null;
    static String qntIni = null;
    static String qntFini = null;
    
    static String categoria = null;
    static String nome = null;
    static String qnt = null;
       
    
     public static void geraPDFSaida() throws FileNotFoundException, BadElementException, IOException{
         Document documentoPDF = new Document();
      
        try{
            String dir = System.getProperty("user.home");
            PdfWriter.getInstance(documentoPDF, new FileOutputStream(dir+"\\Documents\\Relatorio_Saida.pdf"));
            
            documentoPDF.open();
            documentoPDF.setPageSize(PageSize.A4);
            
            Image logoIF = Image.getInstance(dir+"\\Desktop\\Almoxarifado\\logoPdf\\imagemLogo.png");
            logoIF.scaleToFit(50, 50);
            logoIF.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(logoIF);
            
            Paragraph espaco = new Paragraph(" ");
            documentoPDF.add(espaco);
            
            Paragraph pTitulo = new Paragraph(new Phrase(10F , "MINISTÉRIO DA EDUCAÇÃO", FontFactory.getFont(FontFactory.TIMES, 10F, Font.BOLD)));
            pTitulo.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(pTitulo);
            
            Paragraph pTitulo2 = new Paragraph(new Phrase(10F , "Secretaria de Educação Profissional e Tecnológica", FontFactory.getFont(FontFactory.TIMES, 10F, Font.BOLD)));
            pTitulo2.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(pTitulo2);
            
            Paragraph pTitulo3 = new Paragraph(new Phrase(10F , "Instituto Federal de Educação, Ciência e Tecnologia do Sul de Minas Gerais - Campus Passos", FontFactory.getFont(FontFactory.TIMES, 10F, Font.BOLD)));
            pTitulo3.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(pTitulo3);
            
            Paragraph pTitulo4 = new Paragraph(new Phrase(10F , "Rua Mário Ribola, 409, Bairro Penha II , Passos / MG, CEP 37903-358 - Fone: (35) 3526-4856", FontFactory.getFont(FontFactory.TIMES, 10F)));
            pTitulo4.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(pTitulo4);
            
            
            Paragraph tipoPDF = new Paragraph(new Phrase(15F , "Relatorio Saída", FontFactory.getFont(FontFactory.TIMES, 15F)));
            tipoPDF.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(tipoPDF);
            
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
           
                        
            Paragraph cat = new Paragraph(new Phrase(12F , "Categoria: " + categoria, FontFactory.getFont(FontFactory.TIMES, 12F)));
            documentoPDF.add(cat);
            documentoPDF.add(espaco);
            
            Paragraph nom = new Paragraph(new Phrase(12F , "Nome: " + nome, FontFactory.getFont(FontFactory.TIMES, 12F)));
            documentoPDF.add(nom);
            documentoPDF.add(espaco);
            
            Paragraph codP = new Paragraph(new Phrase(12F , "Qunatidade: " + qnt, FontFactory.getFont(FontFactory.TIMES, 12F)));
            documentoPDF.add(codP);
            documentoPDF.add(espaco);

            
            
            PdfPTable tabela = new PdfPTable(6);
                       
            PdfPCell cabecalho6 = new PdfPCell(new Phrase(12F , "Cód.", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho6.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho6);
            
            PdfPCell cabecalho7 = new PdfPCell(new Phrase(12F , "Categoria", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho7.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho7);
            
            PdfPCell cabecalho8 = new PdfPCell(new Phrase(12F , "Nome", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho8.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho8);
            
            
             PdfPCell cabecalho9 = new PdfPCell(new Phrase(12F , "Descrição", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho9.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho9);
            
            PdfPCell cabecalho10 = new PdfPCell(new Phrase(12F , "Qnt. Inicial", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho10.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho10);
            
            PdfPCell cabecalho11 = new PdfPCell(new Phrase(12F , "Qnt. Final", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho11.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho11);
            documentoPDF.add(tabela);
            
            int qntItensLista = 0;
            
            //Insere na tabela a lista de itens 
            for(int i=0; i<qntItensLista;i++){
                
                PdfPCell campo = new PdfPCell(new Phrase(12F ,codItem, FontFactory.getFont(FontFactory.TIMES, 12F)));
                tabela.addCell(campo);

                campo = new PdfPCell(new Phrase(12F , categoria, FontFactory.getFont(FontFactory.TIMES, 12F)));
                tabela.addCell(campo);

                campo = new PdfPCell(new Phrase(12F , nome, FontFactory.getFont(FontFactory.TIMES, 12F)));
                tabela.addCell(campo);
                
                
                campo = new PdfPCell(new Phrase(12F ,descricao, FontFactory.getFont(FontFactory.TIMES, 12F)));
                tabela.addCell(campo);

                campo = new PdfPCell(new Phrase(12F , qntIni, FontFactory.getFont(FontFactory.TIMES, 12F)));
                tabela.addCell(campo);

                campo = new PdfPCell(new Phrase(12F , qntFini, FontFactory.getFont(FontFactory.TIMES, 12F)));
                tabela.addCell(campo);
                
            }
            
            
            
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
           
            Paragraph rpd = new Paragraph(new Phrase(15F , "Passos, dia "+Calendar.DAY_OF_MONTH+" de "+ dataDAO.getMes() +" de "+Calendar.YEAR , FontFactory.getFont(FontFactory.TIMES, 15F)));
            rpd.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(rpd);
            
        }catch(DocumentException de){
            de.printStackTrace();
        }catch(IndexOutOfBoundsException ioe){
            ioe.printStackTrace();
        }finally{
            documentoPDF.close();
            JOptionPane.showMessageDialog(null,"Relatório criado com sucesso!");
        }
    }
}
