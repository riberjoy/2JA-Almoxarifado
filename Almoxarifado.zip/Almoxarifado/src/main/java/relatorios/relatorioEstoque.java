package relatorios;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import dao.dataDAO;
import java.awt.Font;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import javax.swing.JOptionPane;

public class relatorioEstoque {
    //necessário buscar no banco os dados item referente a pessoa selecionada.
    static String nomeItem = null;
    static String descricao = null;
    static String qnt = null;
    static String dataUltComp = null;
    
    static String categoria = null;
    static String cod = null;
       
    
     public static void geraPDFEstoque() throws FileNotFoundException, BadElementException, IOException{
         Document documentoPDF = new Document();
      
        try{
            String dir = System.getProperty("user.home");
            PdfWriter.getInstance(documentoPDF, new FileOutputStream(dir+"\\Documents\\Relatorio_Estoque.pdf"));
            
            documentoPDF.open();
            documentoPDF.setPageSize(PageSize.A4);
            
            Image logoIF = Image.getInstance(dir+"\\Desktop\\Almoxarifado\\logoPdf\\imagemLogo.png");
            logoIF.scaleToFit(50, 50);
            logoIF.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(logoIF);
            
            Paragraph espaco = new Paragraph(" ");
            documentoPDF.add(espaco);
            
            Paragraph pTitulo = new Paragraph(new Phrase(10F , "MINISTÉRIO DA EDUCAÇÃO", FontFactory.getFont(FontFactory.TIMES, 10F, Font.BOLD)));
            pTitulo.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(pTitulo);
            
            Paragraph pTitulo2 = new Paragraph(new Phrase(10F , "Secretaria de Educação Profissional e Tecnológica", FontFactory.getFont(FontFactory.TIMES, 10F, Font.BOLD)));
            pTitulo2.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(pTitulo2);
            
            Paragraph pTitulo3 = new Paragraph(new Phrase(10F , "Instituto Federal de Educação, Ciência e Tecnologia do Sul de Minas Gerais - Campus Passos", FontFactory.getFont(FontFactory.TIMES, 10F, Font.BOLD)));
            pTitulo3.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(pTitulo3);
            
            Paragraph pTitulo4 = new Paragraph(new Phrase(10F , "Rua Mário Ribola, 409, Bairro Penha II , Passos / MG, CEP 37903-358 - Fone: (35) 3526-4856", FontFactory.getFont(FontFactory.TIMES, 10F)));
            pTitulo4.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(pTitulo4);
            
            documentoPDF.add(espaco);
            
            Paragraph tipoPDF = new Paragraph(new Phrase(15F , "Relatório Estoque", FontFactory.getFont(FontFactory.TIMES, 15F)));
            tipoPDF.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(tipoPDF);
            
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
           
                        
            Paragraph cat = new Paragraph(new Phrase(12F , "Categoria: " + categoria, FontFactory.getFont(FontFactory.TIMES, 12F)));
            documentoPDF.add(cat);
            documentoPDF.add(espaco);
            
            Paragraph nom = new Paragraph(new Phrase(12F , "Nome: " + nomeItem, FontFactory.getFont(FontFactory.TIMES, 12F)));
            documentoPDF.add(nom);
            documentoPDF.add(espaco);
            
            Paragraph codP = new Paragraph(new Phrase(12F , "Código: " + cod, FontFactory.getFont(FontFactory.TIMES, 12F)));
            documentoPDF.add(codP);
            documentoPDF.add(espaco);

            
            PdfPTable tabela = new PdfPTable(4);
            
            PdfPCell cabecalho = new PdfPCell(new Phrase(12F , "Nome", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho);
            
            PdfPCell cabecalho2 = new PdfPCell(new Phrase(12F , "Descrição", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho2.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho2);
            
            PdfPCell cabecalho3 = new PdfPCell(new Phrase(12F , "Qnt", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho3.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho3);
            
            PdfPCell cabecalho4 = new PdfPCell(new Phrase(12F , "Dada de última compra", FontFactory.getFont(FontFactory.TIMES, 12F)));
            cabecalho4.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabela.addCell(cabecalho4);
         
                
            PdfPCell nome = new PdfPCell(new Phrase(12F , nomeItem, FontFactory.getFont(FontFactory.TIMES, 12F)));
            tabela.addCell(nome);

            PdfPCell desc = new PdfPCell(new Phrase(12F , descricao, FontFactory.getFont(FontFactory.TIMES, 12F)));
            tabela.addCell(desc);

            PdfPCell qt = new PdfPCell(new Phrase(12F ,qnt, FontFactory.getFont(FontFactory.TIMES, 12F)));
            tabela.addCell(qt);

            PdfPCell dataUlt = new PdfPCell(new Phrase(12F , dataUltComp, FontFactory.getFont(FontFactory.TIMES, 12F)));
            tabela.addCell(dataUlt);
            documentoPDF.add(tabela);
            
            
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
           
            Paragraph rpd = new Paragraph(new Phrase(15F , "Passos, dia "+Calendar.DAY_OF_MONTH+" de "+ dataDAO.getMes() +" de "+Calendar.YEAR , FontFactory.getFont(FontFactory.TIMES, 15F)));
            rpd.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(rpd);
            
        }catch(DocumentException de){
            de.printStackTrace();
        }catch(IndexOutOfBoundsException ioe){
            ioe.printStackTrace();
        }finally{
            documentoPDF.close();
            JOptionPane.showMessageDialog(null,"Relatório criado com sucesso!");
        }
    }
}
