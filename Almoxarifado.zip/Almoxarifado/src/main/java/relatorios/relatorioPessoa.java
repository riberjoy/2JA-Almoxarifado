package relatorios;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Font;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import dao.dataDAO;
import javax.swing.JOptionPane;

public class relatorioPessoa {
    
    //necessário buscar no banco os dados da Pessoa Fisica referente a busca efetuada.
    static String nomePessoaF = null;
    static String sexoPessoaF = null;
    static String cpfPessoaF = null;
    static String dataNascPessoaF = null;
    
    

    //necessário buscar no banco os dados da Pessoa Juridica referente a busca efetuada.
    static String nomePessoaJ = null;
    static String empresaPessoaj = null;
    static String emailPessoaJ = null;
    static String webSitePessoaJ = null;
    static String cnpjPessoaJ = null;
    static String telefonePessoaJ = null;
    static String inscEstadPessoaJ = null;
       
    
    
    public static void geraPDFPessoaFisisca() throws FileNotFoundException, BadElementException, IOException{
        Document documentoPDF = new Document();
      
        try{
            String dir = System.getProperty("user.home");
            PdfWriter.getInstance(documentoPDF, new FileOutputStream(dir+"\\Documents\\Relatorio_Pessoa_Fisica.pdf"));
            
            documentoPDF.open();
            documentoPDF.setPageSize(PageSize.A4);
            
            Image logoIF = Image.getInstance(dir+"\\Desktop\\Almoxarifado\\logoPdf\\imagemLogo.png");
            logoIF.scaleToFit(50, 50);
            logoIF.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(logoIF);
            
            Paragraph espaco = new Paragraph(" ");
            documentoPDF.add(espaco);
            
            Paragraph pTitulo = new Paragraph(new Phrase(10F , "MINISTÉRIO DA EDUCAÇÃO", FontFactory.getFont(FontFactory.TIMES, 10F, Font.BOLD)));
            pTitulo.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(pTitulo);
            
            Paragraph pTitulo2 = new Paragraph(new Phrase(10F , "Secretaria de Educação Profissional e Tecnológica", FontFactory.getFont(FontFactory.TIMES, 10F, Font.BOLD)));
            pTitulo2.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(pTitulo2);
            
            Paragraph pTitulo3 = new Paragraph(new Phrase(10F , "Instituto Federal de Educação, Ciência e Tecnologia do Sul de Minas Gerais - Campus Passos", FontFactory.getFont(FontFactory.TIMES, 10F, Font.BOLD)));
            pTitulo3.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(pTitulo3);
            
            Paragraph pTitulo4 = new Paragraph(new Phrase(10F , "Rua Mário Ribola, 409, Bairro Penha II , Passos / MG, CEP 37903-358 - Fone: (35) 3526-4856", FontFactory.getFont(FontFactory.TIMES, 10F)));
            pTitulo4.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(pTitulo4);
            
            documentoPDF.add(espaco);
            
            Paragraph tipoPDF = new Paragraph(new Phrase(15F , "Pessoa Fisíca", FontFactory.getFont(FontFactory.TIMES, 15F)));
            tipoPDF.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(tipoPDF);
            
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
            
            Paragraph nome = new Paragraph(new Phrase(12F , "Nome: " + nomePessoaF, FontFactory.getFont(FontFactory.TIMES, 12F)));
            documentoPDF.add(nome);
            documentoPDF.add(espaco);
            
            Paragraph sexo = new Paragraph(new Phrase(12F , "Sexo: " + sexoPessoaF, FontFactory.getFont(FontFactory.TIMES, 12F)));
            documentoPDF.add(sexo);
            documentoPDF.add(espaco);
            
            Paragraph cpf = new Paragraph(new Phrase(12F , "CPF: " + cpfPessoaF, FontFactory.getFont(FontFactory.TIMES, 12F)));
            documentoPDF.add(cpf);
            documentoPDF.add(espaco);
            
            Paragraph dataNasc = new Paragraph(new Phrase(12F , "Data de Nascimento: " + nomePessoaF, FontFactory.getFont(FontFactory.TIMES, 12F)));
            documentoPDF.add(dataNasc);
            documentoPDF.add(espaco);
            
            
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
           
            Paragraph rpd = new Paragraph(new Phrase(15F , "Passos, dia "+Calendar.DAY_OF_MONTH+" de "+ dataDAO.getMes() +" de "+Calendar.YEAR , FontFactory.getFont(FontFactory.TIMES, 15F)));
            rpd.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(rpd);
            
        }catch(DocumentException de){
            de.printStackTrace();
        }catch(IndexOutOfBoundsException ioe){
            ioe.printStackTrace();
        }finally{
            documentoPDF.close();
            JOptionPane.showMessageDialog(null,"Relatório criado com sucesso!");
        }
    }
      
    
    public static void geraPDFPessoaJuridica() throws FileNotFoundException, BadElementException, IOException{
         Document documentoPDF = new Document();
      
        try{
            String dir = System.getProperty("user.home");
            PdfWriter.getInstance(documentoPDF, new FileOutputStream(dir+"\\Documents\\Relatorio_Pessoa_Juridica.pdf"));
            
            documentoPDF.open();
            documentoPDF.setPageSize(PageSize.A4);
            
            Image logoIF = Image.getInstance(dir+"\\Desktop\\Almoxarifado\\logoPdf\\imagemLogo.png");
            logoIF.scaleToFit(50, 50);
            logoIF.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(logoIF);
            
            Paragraph espaco = new Paragraph(" ");
            documentoPDF.add(espaco);
            
            Paragraph pTitulo = new Paragraph(new Phrase(10F , "MINISTÉRIO DA EDUCAÇÃO", FontFactory.getFont(FontFactory.TIMES, 10F, Font.BOLD)));
            pTitulo.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(pTitulo);
            
            Paragraph pTitulo2 = new Paragraph(new Phrase(10F , "Secretaria de Educação Profissional e Tecnológica", FontFactory.getFont(FontFactory.TIMES, 10F, Font.BOLD)));
            pTitulo2.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(pTitulo2);
            
            Paragraph pTitulo3 = new Paragraph(new Phrase(10F , "Instituto Federal de Educação, Ciência e Tecnologia do Sul de Minas Gerais - Campus Passos", FontFactory.getFont(FontFactory.TIMES, 10F, Font.BOLD)));
            pTitulo3.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(pTitulo3);
            
            Paragraph pTitulo4 = new Paragraph(new Phrase(10F , "Rua Mário Ribola, 409, Bairro Penha II , Passos / MG, CEP 37903-358 - Fone: (35) 3526-4856", FontFactory.getFont(FontFactory.TIMES, 10F)));
            pTitulo4.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(pTitulo4);
            
            documentoPDF.add(espaco);
            
            Paragraph tipoPDF = new Paragraph(new Phrase(15F , "Pessoa Jurídica", FontFactory.getFont(FontFactory.TIMES, 15F)));
            tipoPDF.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(tipoPDF);
            
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
           
            
            Paragraph nome = new Paragraph(new Phrase(12F , "Nome: " + nomePessoaJ, FontFactory.getFont(FontFactory.TIMES, 12F)));
            documentoPDF.add(nome);
            documentoPDF.add(espaco);
            
            Paragraph empresa = new Paragraph(new Phrase(12F , "Nome da empresa: " + empresaPessoaj, FontFactory.getFont(FontFactory.TIMES, 12F)));
            documentoPDF.add(empresa);
            documentoPDF.add(espaco);
            
            Paragraph email = new Paragraph(new Phrase(12F , "E-mai: " + emailPessoaJ, FontFactory.getFont(FontFactory.TIMES, 12F)));
            documentoPDF.add(email);
            documentoPDF.add(espaco);
            
            Paragraph web = new Paragraph(new Phrase(12F , "Web site: " + webSitePessoaJ, FontFactory.getFont(FontFactory.TIMES, 12F)));
            documentoPDF.add(web);
            documentoPDF.add(espaco);
            
            Paragraph cnpj = new Paragraph(new Phrase(12F , "CNPJ: " + cnpjPessoaJ, FontFactory.getFont(FontFactory.TIMES, 12F)));
            documentoPDF.add(cnpj);
            documentoPDF.add(espaco);
            
            Paragraph fone = new Paragraph(new Phrase(12F , "Telefone: " + telefonePessoaJ, FontFactory.getFont(FontFactory.TIMES, 12F)));
            documentoPDF.add(fone);
            documentoPDF.add(espaco);
            
            Paragraph insc = new Paragraph(new Phrase(12F , "Inscrição Estadual: " + inscEstadPessoaJ, FontFactory.getFont(FontFactory.TIMES, 12F)));
            documentoPDF.add(insc);
            documentoPDF.add(espaco);
            
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
            documentoPDF.add(espaco);
           
            Paragraph rpd = new Paragraph(new Phrase(15F , "Passos, dia "+Calendar.DAY_OF_MONTH+" de "+ dataDAO.getMes() +" de "+Calendar.YEAR , FontFactory.getFont(FontFactory.TIMES, 15F)));
            rpd.setAlignment(Element.ALIGN_CENTER);
            documentoPDF.add(rpd);
            
        }catch(DocumentException de){
            de.printStackTrace();
        }catch(IndexOutOfBoundsException ioe){
            ioe.printStackTrace();
        }finally{
            documentoPDF.close();
            JOptionPane.showMessageDialog(null,"Relatório criado com sucesso!");
        }
    }
}
