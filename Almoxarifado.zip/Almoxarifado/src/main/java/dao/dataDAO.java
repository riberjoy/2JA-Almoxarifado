package dao;

import java.util.Calendar;
import javax.swing.JOptionPane;

 
public class dataDAO {
    
    static String dia = null;
    
    public static String getMes(){ 
    
        switch(Calendar.MONTH){
            case 1:
                dia = "Janeiro";
                break;
            case 2:
                dia = "Fevereiro";
                break;
            case 3:
                dia = "Março";
                break;
            case 4:
                dia = "Abril";
                break;
            case 5:
                dia = "Maio";
                break;
            case 6:
                dia = "Junho";
                break;
            case 7:
                dia = "Julho";
                break;
            case 8:
                dia = "Agosto";
                break;
            case 9:
                dia = "Setembro";
                break;
            case 10:
                dia = "Outubro";
                break;    
            case 11:
                dia = "Novembro";
                break;    
            case 12:
                dia = "Dezembro";
                break; 
            default:
                JOptionPane.showMessageDialog(null,"Erro ao selecionar o mês!");
                break;
        }
        return dia;
    }
}
